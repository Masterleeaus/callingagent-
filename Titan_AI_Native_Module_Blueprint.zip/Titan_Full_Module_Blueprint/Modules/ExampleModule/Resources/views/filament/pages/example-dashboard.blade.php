<x-filament-panels::page>Example dashboard</x-filament-panels::page>
