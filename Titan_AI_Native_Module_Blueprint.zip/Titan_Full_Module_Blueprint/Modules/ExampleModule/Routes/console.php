<?php
// Console route definitions.
