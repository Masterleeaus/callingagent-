<?php
use Illuminate\Support\Facades\Route;use Modules\ExampleModule\Http\Controllers\Api\ExampleApiController;
Route::get('/records',[ExampleApiController::class,'index'])->name('records.index');Route::post('/records',[ExampleApiController::class,'store'])->name('records.store');
