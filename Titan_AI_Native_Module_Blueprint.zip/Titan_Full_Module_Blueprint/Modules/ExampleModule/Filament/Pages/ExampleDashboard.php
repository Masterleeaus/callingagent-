<?php

namespace Modules\ExampleModule\Filament\Pages;

class ExampleDashboard
{
    protected static string $view = "example-module::filament.pages.example-dashboard";
}
