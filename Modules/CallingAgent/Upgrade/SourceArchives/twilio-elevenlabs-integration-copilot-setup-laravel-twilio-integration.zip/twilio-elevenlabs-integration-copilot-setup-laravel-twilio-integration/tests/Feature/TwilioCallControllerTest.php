<?php

namespace Tests\Feature;

use Tests\TestCase;

class TwilioCallControllerTest extends TestCase
{
    public function test_incoming_call_returns_twiml_response(): void
    {
        $response = $this->post('/twilio/incoming');

        $response->assertStatus(200);
        $response->assertHeader('Content-Type', 'text/xml; charset=UTF-8');
        $response->assertSee('<Response>', false);
        $response->assertSee('<Say>', false);
    }

    public function test_status_callback_returns_no_content(): void
    {
        $response = $this->post('/twilio/status');

        $response->assertStatus(204);
    }
}
