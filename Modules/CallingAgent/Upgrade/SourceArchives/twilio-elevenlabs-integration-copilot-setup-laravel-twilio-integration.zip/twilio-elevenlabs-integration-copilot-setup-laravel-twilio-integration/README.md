# twilio-elevenlabs-integration
AI call agent built with Laravel that handles incoming calls via Twilio and generates natural voice responses using ElevenLabs.

## Requirements

- PHP 8.2+
- Composer
- A [Twilio](https://www.twilio.com/) account with a phone number
- An [ElevenLabs](https://elevenlabs.io/) account and API key

## Setup

1. **Install dependencies**

   ```bash
   composer install
   ```

2. **Copy environment file and configure**

   ```bash
   cp .env.example .env
   php artisan key:generate
   ```

   Edit `.env` and fill in your credentials:

   ```
   TWILIO_ACCOUNT_SID=your_account_sid_here
   TWILIO_AUTH_TOKEN=your_auth_token_here
   TWILIO_PHONE_NUMBER=+1XXXXXXXXXX

   ELEVENLABS_API_KEY=your_elevenlabs_api_key_here
   ELEVENLABS_VOICE_ID=your_voice_id_here
   ```

3. **Run migrations**

   ```bash
   php artisan migrate
   ```

4. **Start the development server**

   ```bash
   php artisan serve
   ```

## Twilio Webhook Configuration

Point the following Twilio webhook URLs to your server (use [ngrok](https://ngrok.com/) for local development):

| Event | Method | URL |
|---|---|---|
| Incoming call | POST | `https://your-domain.com/twilio/incoming` |
| Call status callback | POST | `https://your-domain.com/twilio/status` |

## Running Tests

```bash
php artisan test
```
