<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TwilioCallController;

Route::get('/', function () {
    return view('welcome');
});

// Twilio webhook endpoints – exclude from CSRF verification (see bootstrap/app.php)
Route::post('/twilio/incoming', [TwilioCallController::class, 'incoming'])->name('twilio.incoming');
Route::post('/twilio/status', [TwilioCallController::class, 'status'])->name('twilio.status');
