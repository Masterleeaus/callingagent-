@php
	use App\Extensions\MarketingBot\System\Enums\CampaignStatus;
@endphp

<h3 class="col-span-2 self-center mb-2 pb-2 mt-5">
	@lang('Campaigns')
</h3>

<div class="py-10">
	<x-table>
		<x-slot:head>
			<th>
				{{ __('ID') }}
			</th>
			<th>
				{{ __('Name') }}
			</th>
			<th>
				{{ __('Status') }}
			</th>
			<th>
				{{ __('Platform') }}
			</th>

			<th>
				{{ __('Schedule at') }}
			</th>

			<th class="text-end">
				{{ __('Action') }}
			</th>
		</x-slot:head>

		<x-slot:body>
			@foreach ($campaignList as $item)
				<tr>
					<td>
						{{ $item->id }}
					</td>
					<td>
						{{ $item->name }}
					</td>
					<td>
						<p @class([
								'lqd-posts-item-type sort-file inline-flex w-auto m-0 items-center gap-1.5 justify-self-start whitespace-nowrap rounded-full border px-2 py-1 text-[12px] font-medium leading-none',
								'text-green-500' => $item['status'] === CampaignStatus::published,
								'text-yellow-700' => $item['status'] === CampaignStatus::scheduled,
							])>
							@if ($item['status'] === CampaignStatus::published)
								<x-tabler-check class="size-4" />
							@elseif ($item['status'] ===  CampaignStatus::scheduled)
								<x-tabler-clock class="size-4" />
							@else
								<x-tabler-circle-dashed class="size-4" />
							@endif
							@lang(str()->title($item->status->value))
						</p>
					</td>
					<td>
						<img alt="{{ $item->type->name }}" src="{{ asset('vendor/marketing-bot/images/' . $item->type->value . '.png' ) }}" />
					</td>
					<td>
						{{ $item->scheduled_at ? $item->scheduled_at->format('Y-m-d H:i') : __('Not scheduled') }}
					</td>
					<td class="whitespace-nowrap text-end">
						@if ($app_is_demo)
							<x-button
								class="size-9"
								variant="ghost-shadow"
								hover-variant="danger"
								size="none"
								onclick="return toastr.info('This feature is disabled in Demo version.')"
								title="{{ __('Delete') }}"
							>
								<x-tabler-x class="size-4" />
							</x-button>
						@else
							<x-button
								href="{{ route('dashboard.user.marketing-bot.' . $item->type->value . '-campaign.edit', $item->id) }}"
								class="size-9"
								variant="ghost-shadow"
								size="none"
								title="{{ __('Delete') }}"
							>
								<x-tabler-edit class="size-4" />
							</x-button>
							<x-button
								data-delete="delete"
								data-delete-link="{{ route('dashboard.user.marketing-bot.' . $item->type->value . '-campaign.destroy', $item->id) }}"
								class="size-9"
								variant="ghost-shadow"
								hover-variant="danger"
								size="none"
								title="{{ __('Delete') }}"
							>
								<x-tabler-x class="size-4" />
							</x-button>

						@endif
					</td>
				</tr>
			@endforeach
		</x-slot:body>
	</x-table>

	<div class="mt-3 flex justify-end">
		{{ $campaignList->links() }}
	</div>
</div>
