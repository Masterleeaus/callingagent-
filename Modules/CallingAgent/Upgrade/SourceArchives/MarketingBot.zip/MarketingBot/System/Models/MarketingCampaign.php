<?php

namespace App\Extensions\MarketingBot\System\Models;

use App\Extensions\MarketingBot\System\Enums\CampaignStatus;
use App\Extensions\MarketingBot\System\Enums\CampaignType;
use Illuminate\Database\Eloquent\Model;

class MarketingCampaign extends Model
{
    protected $table = 'ext_marketing_campaigns';

    protected $fillable = [
        'template_id',
        'user_id',
        'name',
        'content',
        'image',
        'contacts',
        'segments',
        'type',
        'status',
        'scheduled_at',
        'started_at',
        'finished_at',
    ];

    protected $casts = [
        'status'       => CampaignStatus::class,
        'type'         => CampaignType::class,
        'contacts'     => 'array',
        'segments'     => 'array',
        'scheduled_at' => 'datetime',
        'started_at'   => 'datetime',
        'finished_at'  => 'datetime',
    ];
}
