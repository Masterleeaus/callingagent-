<?php

namespace App\Extensions\MarketingBot\System\Http\Controllers\Whatsapp;

use App\Extensions\MarketingBot\System\Http\Requests\ContactRequest;
use App\Extensions\MarketingBot\System\Models\Whatsapp\Contact;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Auth;

class ContactController extends Controller
{
    // Controller logic goes here

    public function index()
    {
        return view('marketing-bot::contact.index', [
            'title' => trans('Contact Lists'),
            'items' => Contact::query()->where('user_id', Auth::id())->get(),
        ]);
    }

    public function store(ContactRequest $request): JsonResponse
    {
        Contact::query()->create($request->validated());

        return response()->json([
            'status'  => 'success',
            'message' => __('Contact created successfully'),
        ]);
    }

    public function edit(Contact $contact)
    {
        return view('marketing-bot::contact.edit', [
            'item'  => $contact,
            'title' => trans('Contact List Edit'),
        ]);
    }

    public function update(ContactRequest $request, Contact $contact): \Illuminate\Http\RedirectResponse
    {
        $contact->update($request->validated());

        return back()->with([
            'status'  => 'success',
            'message' => __('Contact updated successfully'),
            'type'    => 'success',
        ]);
    }

    public function destroy(Contact $contact): JsonResponse
    {
        $contact->delete();

        return response()->json([
            'status'  => 'success',
            'message' => __('Contact deleted successfully'),
        ]);
    }
}
