<?php

namespace App\Extensions\MarketingBot\System\Http\Controllers\Campaign;

use App\Extensions\MarketingBot\System\Http\Requests\Campaign\CampaignTelegramRequest;
use App\Extensions\MarketingBot\System\Models\MarketingCampaign;
use App\Extensions\MarketingBot\System\Models\Telegram\TelegramContact;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

class TelegramCampaignController extends Controller
{
    public function index()
    {
        return view('marketing-bot::telegram-campaign.index', [
            'title' => 'Telegram Campaigns',
            'items' => MarketingCampaign::query()
                ->where('type', 'telegram')
                ->where('user_id', Auth::id())
                ->orderByDesc('created_at')
                ->paginate(10),
        ]);
    }

    public function create(): View
    {
        return view('marketing-bot::telegram-campaign.create', [
            'title'           => trans('New Telegram Campaign'),
            'action'          => route('dashboard.user.marketing-bot.telegram-campaign.store'),
            'method'          => 'POST',
            'item'            => new MarketingCampaign,
            'contacts'        => TelegramContact::query()->where('user_id', Auth::id())->get(),
            'selectedContact' => [],
        ]);
    }

    public function store(CampaignTelegramRequest $request): RedirectResponse
    {
        $data = $request->validated();

        MarketingCampaign::query()->create($data);

        return redirect()->route('dashboard.user.marketing-bot.telegram-campaign.index')
            ->with([
                'type'    => 'success',
                'message' => trans('Telegram campaign created'),
            ]);
    }

    public function edit(Request $request, MarketingCampaign $telegramCampaign): View
    {
        return view('marketing-bot::telegram-campaign.create', [
            'title'           => trans('Edit Telegram Campaign'),
            'action'          => route('dashboard.user.marketing-bot.telegram-campaign.store'),
            'method'          => 'POST',
            'item'            => $telegramCampaign,
            'contacts'        => TelegramContact::query()->where('user_id', Auth::id())->get(),
            'selectedContact' => $telegramCampaign->getAttribute('contacts') ?: [],
        ]);
    }

    public function update(CampaignTelegramRequest $request, MarketingCampaign $telegramCampaign): RedirectResponse
    {
        $telegramCampaign->update($request->validated());

        return redirect()->route('dashboard.user.marketing-bot.telegram-campaign.index')
            ->with([
                'type'    => 'success',
                'message' => trans('Telegram campaign updated'),
            ]);
    }

    public function destroy(MarketingCampaign $telegramCampaign): JsonResponse
    {
        $telegramCampaign->delete();

        return response()->json([
            'status'  => 'success',
            'message' => trans('Telegram campaign deleted'),
        ]);
    }

    public function show(MarketingCampaign $telegramCampaign) {}
}
