<?php

namespace App\Extensions\MarketingBot\System\Http\Controllers;

use App\Extensions\MarketingBot\System\Enums\CampaignType;
use App\Extensions\MarketingBot\System\Models\MarketingCampaign;
use App\Extensions\MarketingBot\System\Models\Whatsapp\Contact;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Auth;

class MarketingDashboardController extends Controller
{
    public function __invoke(Request $request)
    {
        $lastTenDays = $this->lastTenDays();

        return view('marketing-bot::dashboard.index', [
            'totals'                 => $this->getTotals(),
            'chartCampaigns'         => $this->getCampaigns(),
            'chartNewContacts'       => $this->getNewContacts(),
            'campaignList'           => MarketingCampaign::query()->where('user_id', Auth::id())
                ->orderByDesc('id')
                ->paginate(10),
            'lastTenDays' => $lastTenDays,
        ]);
    }

    public function getNewContacts(): array
    {
        $startDate = Carbon::now()->subDays(10);

        $endDate = Carbon::now();

        $query = Contact::selectRaw("
            DATE_FORMAT(created_at, '%d-%m') as day_month,
            COUNT(*) as count
        ")
            ->whereBetween('created_at', [$startDate, $endDate])
            ->groupBy('day_month')
            ->orderBy('day_month')
            ->get();

        $days = collect(range(0, 9))->map(function ($i) {
            return Carbon::now()->subDays($i)->format('d-m');
        })->reverse()->values();

        return [
            [
                'name' => 'whatsapp',
                'data' => $days->map(function ($day) use ($query) {
                    return $query->where('day_month', $day)->sum('count') ?? 0;
                })->toArray(),
            ],
        ];
    }

    public function getCampaigns(): array
    {
        $startDate = Carbon::now()->subDays(10);

        $endDate = Carbon::now();

        $types = [
            CampaignType::whatsapp->value,
            CampaignType::telegram->value,
        ];

        $query = MarketingCampaign::selectRaw("
            type,
            DATE_FORMAT(created_at, '%d-%m') as day_month,
            COUNT(*) as count
        ")
            ->where('status', 'published')
            ->whereBetween('scheduled_at', [$startDate, $endDate])
            ->groupBy('type', 'day_month')
            ->orderBy('day_month')
            ->get();

        $days = collect(range(0, 9))->map(function ($i) {
            return Carbon::now()->subDays($i)->format('d-m');
        })->reverse()->values();

        return collect($types)->map(function ($type) use ($query, $days) {
            return [
                'name' => $type,
                'data' => $days->map(function ($day) use ($query, $type) {
                    return $query->where('type', $type)->where('day_month', $day)->sum('count') ?? 0;
                })
                    ->toArray(),
            ];
        })->toArray();
    }

    public function getTotals(): array
    {
        return [
            'today'        => $this->total(Carbon::today(), Carbon::now()),
            'last_7_days'  => $this->total(Carbon::now()->subDays(7), Carbon::now()),
            'last_30_days' => $this->total(Carbon::now()->subDays(30), Carbon::now()),
        ];
    }

    public function total($startDate, $endDate): array
    {
        $data = MarketingCampaign::query()
            ->selectRaw("
            COUNT(*) as campaigns,
            SUM(CASE WHEN status = 'published' THEN 1 ELSE 0 END) as published_campaigns,
            SUM(CASE WHEN status = 'scheduled' THEN 1 ELSE 0 END) as scheduled_campaigns
        ")
            ->whereBetween('scheduled_at', [$startDate, $endDate])
            ->first();

        $totalContacts = MarketingCampaign::query()
            ->whereBetween('scheduled_at', [$startDate, $endDate])
            ->count();

        return [
            'campaigns'           => $data?->campaigns ?: 0,
            'scheduled_campaigns' => $data?->scheduled_campaigns ?: 0,
            'published_campaigns' => $data?->published_campaigns ?: 0,
            'total_contacts'      => $totalContacts,
        ];
    }

    public function lastTenDays(): array
    {
        $list = [];
        $bugun = Carbon::today();

        for ($i = 0; $i < 10; $i++) {
            $list[] = $bugun->copy()->subDays($i)->format('d M');
        }

        return $list;
    }
}
