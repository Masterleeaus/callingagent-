<?php

return [
    'insufficient_credits' => 'عذراً، رصيدك غير كافٍ. يرجى شحن الرصيد للمتابعة. شكراً لك.',
];
