<script setup>
import { ref, onMounted } from 'vue';
import { usePage } from '@inertiajs/vue3';

const activeCall = ref(null);
const page = usePage();

const translateStatus = (status) => {
    switch (status) {
        case 'ringing': return 'جاري الاتصال...';
        case 'in-progress': return 'متصل';
        case 'completed': return 'منتهية';
        default: return status;
    }
};

onMounted(() => {
    const tenantId = page.props.auth.user.tenant_id;
    if (tenantId) {
        window.Echo.private(`tenant.${tenantId}`)
            .listen('.call.status.changed', (e) => {
                activeCall.value = e.callData;
                if (e.callData.status === 'completed') {
                    setTimeout(() => activeCall.value = null, 3000);
                }
            });
    }
});
</script>

<template>
    <div v-if="activeCall" class="fixed top-4 right-4 z-[60] w-80 animate-in slide-in-from-right duration-300">
        <div class="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl border border-blue-100 dark:border-blue-900 overflow-hidden">
            <div class="p-4 bg-blue-600 text-white flex justify-between items-center">
                <div class="flex items-center space-x-2">
                    <div class="w-2 h-2 rounded-full bg-white animate-ping"></div>
                    <span class="font-bold text-sm uppercase tracking-wider">مكالمة نشطة</span>
                </div>
                <span class="text-xs font-mono opacity-80">{{ activeCall.duration || '00:00' }}</span>
            </div>
            
            <div class="p-5 flex items-center">
                <div class="w-12 h-12 rounded-full bg-blue-50 dark:bg-blue-900/30 flex items-center justify-center text-blue-600 dark:text-blue-400 mr-4">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                    </svg>
                </div>
                <div>
                    <p class="text-sm font-bold text-gray-800 dark:text-white">{{ activeCall.from }}</p>
                    <p class="text-xs text-gray-500 dark:text-gray-400">الحالة: <span class="text-blue-500 font-medium">{{ translateStatus(activeCall.status) }}</span></p>
                </div>
            </div>
            
            <div v-if="activeCall.status === 'ringing'" class="p-4 bg-gray-50 dark:bg-gray-900/50 flex space-x-3">
                <button class="flex-1 py-2 bg-green-500 hover:bg-green-600 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-green-500/20 active:scale-95">رد</button>
                <button class="flex-1 py-2 bg-red-500 hover:bg-red-600 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-red-500/20 active:scale-95">رفض</button>
            </div>
        </div>
    </div>
</template>
