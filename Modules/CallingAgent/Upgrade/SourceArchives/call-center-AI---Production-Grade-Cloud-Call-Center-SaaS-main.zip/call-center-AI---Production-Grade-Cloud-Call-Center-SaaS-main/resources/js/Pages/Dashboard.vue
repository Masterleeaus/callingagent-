<script setup>
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import { Head } from '@inertiajs/vue3';
import HealthStatus from '@/Components/HealthStatus.vue';

const stats = [
    { label: 'إجمالي المكالمات', value: '1,284', trend: '+12%', trendUp: true },
    { label: 'متوسط المدة', value: '4 د 32 ث', trend: '-5%', trendUp: true },
    { label: 'نسبة النجاح', value: '94.2%', trend: '+0.4%', trendUp: true },
    { label: 'توفير الذكاء الاصطناعي', value: '$4,120', trend: '+22%', trendUp: true },
];
</script>

<template>
    <Head title="Dashboard" />

    <AuthenticatedLayout>
        <template #header>
            <h2 class="text-xl font-semibold leading-tight text-gray-800 dark:text-gray-200">
                لوحة التحكم
            </h2>
        </template>

        <div class="py-12">
            <div class="mx-auto max-w-7xl sm:px-6 lg:px-8">
                <!-- System Health Check (Admin Only) -->
                <div class="mb-10">
                    <h3 class="text-lg font-bold text-gray-800 dark:text-white mb-4 flex items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2 text-blue-500" viewBox="0 0 20 20" fill="currentColor">
                            <path fill-rule="evenodd" d="M2.166 4.999A11.954 11.954 0 0010 1.944 11.954 11.954 0 0017.834 5c.11.65.166 1.32.166 2.001 0 5.225-3.34 9.67-8 11.317C5.34 16.67 2 12.225 2 7c0-.682.057-1.35.166-2.001zm11.541 3.708a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" />
                        </svg>
                        حالة النظام
                    </h3>
                    <HealthStatus />
                </div>

                <!-- Stats Overview -->
                <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                    <div v-for="stat in stats" :key="stat.label" class="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700">
                        <p class="text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">{{ stat.label }}</p>
                        <h3 class="text-3xl font-bold text-gray-800 dark:text-white">{{ stat.value }}</h3>
                        <div class="mt-2 flex items-center text-xs" :class="stat.trendUp ? 'text-green-500' : 'text-red-500'">
                            <span>{{ stat.trend }}</span>
                            <span class="mr-1">مقارنة بآخر 24 ساعة</span>
                        </div>
                    </div>
                </div>

                <!-- Main Content Grid -->
                <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    <!-- Live Activity -->
                    <div class="lg:col-span-2 bg-white dark:bg-gray-800 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden">
                        <div class="p-6 border-b border-gray-50 dark:border-gray-700 flex justify-between items-center">
                            <h3 class="font-bold text-gray-800 dark:text-white text-lg">النشاط المباشر</h3>
                            <span class="px-3 py-1 bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400 text-xs font-bold rounded-full uppercase tracking-wider">مباشر الآن</span>
                        </div>
                        <div class="p-6">
                            <div class="space-y-4">
                                <div v-for="i in 3" :key="i" class="flex items-center p-4 rounded-xl bg-gray-50 dark:bg-gray-900/50 border border-gray-100 dark:border-gray-700">
                                    <div class="w-10 h-10 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center text-blue-600 dark:text-blue-400 mr-4">
                                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                                            <path d="M2 3a1 1 0 011-1h2.153a1 1 0 01.986.836l.74 4.435a1 1 0 01-.54 1.06l-1.548.773a11.037 11.037 0 006.105 6.105l.774-1.548a1 1 0 011.059-.54l4.435.74a1 1 0 01.836.986V17a1 1 0 01-1 1h-2C7.82 18 2 12.18 2 5V3z" />
                                        </svg>
                                    </div>
                                    <div class="flex-1">
                                        <p class="font-bold text-gray-800 dark:text-white text-sm">+1 234 567 890</p>
                                        <p class="text-xs text-gray-500 dark:text-gray-400">متصل بالوكيل سارة</p>
                                    </div>
                                    <div class="text-right">
                                        <p class="text-xs font-mono text-gray-400">02:45</p>
                                        <p class="text-[10px] text-green-500 font-bold uppercase tracking-tighter">نشط</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- AI Insights -->
                    <div class="bg-gradient-to-br from-indigo-600 to-purple-700 rounded-3xl p-8 shadow-xl text-white relative overflow-hidden h-fit">
                        <div class="relative z-10">
                            <h3 class="text-2xl font-bold mb-4">مشاعر العملاء</h3>
                            <p class="text-indigo-100 text-sm mb-6 leading-relaxed">أفاد معظم العملاء بتجارب إيجابية مع تدفق قائمة IVR الجديد.</p>
                            
                            <div class="bg-white/10 backdrop-blur-md rounded-2xl p-4 border border-white/20 mb-4">
                                <div class="flex justify-between items-center mb-2">
                                    <span class="text-xs font-medium text-indigo-100">المشاعر الإيجابية</span>
                                    <span class="text-xs font-bold font-mono">84%</span>
                                </div>
                                <div class="h-2 bg-white/10 rounded-full overflow-hidden">
                                    <div class="h-full bg-green-400 w-[84%]"></div>
                                </div>
                            </div>
                            
                            <button class="w-full py-4 bg-white text-indigo-600 font-bold rounded-2xl hover:bg-opacity-90 transition-all shadow-lg active:scale-[0.98]">
                                عرض التحليل التفصيلي
                            </button>
                        </div>
                        
                        <!-- Decoration -->
                        <div class="absolute -right-20 -bottom-20 w-64 h-64 bg-white/10 rounded-full blur-3xl"></div>
                    </div>
                </div>
            </div>
        </div>
    </AuthenticatedLayout>
</template>
