<script setup>
import { ref } from "vue";

const number = ref("");
const isCalling = ref(false);

const addDigit = (digit) => {
    number.value += digit;
};

const clear = () => {
    number.value = "";
};

const toggleCall = () => {
    isCalling.value = !isCalling.value;
    // Twilio Device logic would go here
};
</script>

<template>
    <div
        class="fixed right-4 bottom-4 w-72 bg-white dark:bg-gray-800 shadow-2xl rounded-2xl border border-gray-200 dark:border-gray-700 overflow-hidden z-50"
    >
        <div
            class="p-4 border-b border-gray-100 dark:border-gray-700 flex justify-between items-center bg-gray-50 dark:bg-gray-900"
        >
            <h3 class="font-bold text-gray-700 dark:text-gray-200">
                لوحة الاتصال
            </h3>
            <div class="flex space-x-2">
                <span
                    class="w-3 h-3 rounded-full bg-green-500 animate-pulse"
                ></span>
                <span class="text-xs text-gray-500 dark:text-gray-400"
                    >متصل</span
                >
            </div>
        </div>

        <div class="p-4">
            <div
                class="mb-4 bg-gray-50 dark:bg-gray-900 p-3 rounded-xl border border-gray-100 dark:border-gray-700"
            >
                <input
                    v-model="number"
                    type="text"
                    class="w-full text-2xl font-mono text-center bg-transparent border-none focus:ring-0 text-gray-800 dark:text-white"
                    placeholder="أدخل الرقم"
                />
            </div>

            <div class="grid grid-cols-3 gap-2 mb-4">
                <button
                    v-for="n in [
                        '1',
                        '2',
                        '3',
                        '4',
                        '5',
                        '6',
                        '7',
                        '8',
                        '9',
                        '*',
                        '0',
                        '#',
                    ]"
                    :key="n"
                    @click="addDigit(n)"
                    class="h-12 flex items-center justify-center rounded-xl bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors text-xl font-semibold text-gray-700 dark:text-gray-200"
                >
                    {{ n }}
                </button>
            </div>

            <div class="flex space-x-2">
                <button
                    @click="clear"
                    class="flex-1 h-12 bg-gray-200 dark:bg-gray-600 rounded-xl font-bold text-gray-700 dark:text-gray-200 hover:bg-gray-300 dark:hover:bg-gray-500 transition-colors"
                >
                    مسح
                </button>
                <button
                    @click="toggleCall"
                    :class="[
                        'flex-[2] h-12 rounded-xl font-bold text-white transition-all transform active:scale-95',
                        isCalling
                            ? 'bg-red-500 hover:bg-red-600'
                            : 'bg-green-500 hover:bg-green-600',
                    ]"
                >
                    {{ isCalling ? "إنهاء المكالمة" : "اتصال" }}
                </button>
            </div>
        </div>

        <div
            v-if="isCalling"
            class="p-4 bg-red-50 dark:bg-red-900/20 border-t border-red-100 dark:border-red-900/30"
        >
            <div
                class="flex items-center space-x-3 text-red-600 dark:text-red-400"
            >
                <div class="flex space-x-1">
                    <div class="w-1 h-4 bg-current animate-bounce"></div>
                    <div
                        class="w-1 h-4 bg-current animate-bounce [animation-delay:0.2s]"
                    ></div>
                    <div
                        class="w-1 h-4 bg-current animate-bounce [animation-delay:0.4s]"
                    ></div>
                </div>
                <span class="text-sm font-medium">جاري الاتصال...</span>
            </div>
        </div>
    </div>
</template>
