<script setup>
import { ref, onMounted } from 'vue';
import axios from 'axios';

const stats = ref({
    twilio: { status: 'loading', message: 'جاري فحص تويليو...' },
    openai: { status: 'loading', message: 'جاري فحص أوبن إيه آي...' },
    elevenlabs: { status: 'loading', message: 'جاري فحص إيليفن لابس...' },
});

const checkHealth = async () => {
    try {
        const response = await axios.get('/admin/health');
        stats.value = response.data;
    } catch (error) {
        console.error('Health check failed', error);
    }
};

onMounted(() => {
    checkHealth();
    setInterval(checkHealth, 60000); // Check every minute
});

const getStatusColor = (status) => {
    switch (status) {
        case 'healthy': return 'bg-green-500';
        case 'degraded': return 'bg-yellow-500';
        case 'unhealthy': return 'bg-red-500';
        default: return 'bg-gray-400';
    }
};

const translateStatus = (status) => {
    switch (status) {
        case 'healthy': return 'سليم';
        case 'degraded': return 'ضعيف';
        case 'unhealthy': return 'معطل';
        default: return 'جاري التحميل';
    }
};

const translateService = (service) => {
    switch (service) {
        case 'twilio': return 'تويليو';
        case 'openai': return 'أوبن إيه آي';
        case 'elevenlabs': return 'إيليفن لابس';
        default: return service;
    }
};
</script>

<template>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div v-for="(data, service) in stats" :key="service" 
             class="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-lg border-l-4"
             :class="data.status === 'healthy' ? 'border-green-500' : (data.status === 'degraded' ? 'border-yellow-500' : 'border-red-500')">
            
            <div class="flex justify-between items-start mb-4">
                <h3 class="text-lg font-bold capitalize text-gray-800 dark:text-white">{{ translateService(service) }}</h3>
                <div :class="['px-2 py-1 rounded text-[10px] text-white font-bold uppercase shadow-sm', getStatusColor(data.status)]">
                    {{ translateStatus(data.status) }}
                </div>
            </div>
            
            <p class="text-sm text-gray-600 dark:text-gray-400 mb-4">{{ data.message }}</p>
            
            <div v-if="data.remaining !== undefined" class="mt-4 pt-4 border-t border-gray-100 dark:border-gray-700">
                <div class="flex justify-between text-xs">
                    <span class="text-gray-500">الرصيد المتبقي</span>
                    <span class="font-mono font-bold text-blue-600">{{ data.remaining }}</span>
                </div>
            </div>
        </div>
    </div>
</template>
