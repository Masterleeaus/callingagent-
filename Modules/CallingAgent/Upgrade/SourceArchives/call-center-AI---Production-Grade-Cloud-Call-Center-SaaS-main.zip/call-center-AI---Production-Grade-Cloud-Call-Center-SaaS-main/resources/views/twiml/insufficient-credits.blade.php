{!! '<' . '?xml version="1.0" encoding="UTF-8"?' . '>' !!}
<Response>
    <Say voice="{{ $voice }}" language="{{ $language }}">{{ $message }}</Say>
    <Hangup/>
</Response>
