<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('tenants', function (Blueprint $table) {
            $table->integer('minutes_balance')->default(0);
        });

        Schema::table('call_logs', function (Blueprint $table) {
            $table->boolean('is_billed')->default(false);
            $table->integer('duration_minutes')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('tenants', function (Blueprint $table) {
            $table->dropColumn('minutes_balance');
        });

        Schema::table('call_logs', function (Blueprint $table) {
            $table->dropColumn(['is_billed', 'duration_minutes']);
        });
    }
};
