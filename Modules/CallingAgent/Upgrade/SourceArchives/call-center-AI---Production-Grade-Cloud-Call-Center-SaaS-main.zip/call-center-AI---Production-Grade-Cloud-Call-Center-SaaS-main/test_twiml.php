<?php

require __DIR__ . '/vendor/autoload.php';

$app = require_once __DIR__ . '/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

try {
    echo view('twiml.insufficient-credits', [
        'message' => 'عذراً، رصيدك غير كافٍ.',
        'voice' => 'Polly.Zeina',
        'language' => 'ar-XA'
    ])->render();
} catch (\Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
    echo "Line: " . $e->getLine() . "\n";
}
