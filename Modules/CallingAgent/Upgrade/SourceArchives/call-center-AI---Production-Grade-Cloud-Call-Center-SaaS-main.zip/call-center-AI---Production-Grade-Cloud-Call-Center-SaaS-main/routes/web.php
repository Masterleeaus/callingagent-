<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Foundation\Application;
use Illuminate\Support\Facades\Route;
use Inertia\Inertia;

Route::get('/', function () {
    return Inertia::render('Welcome', [
        'canLogin' => Route::has('login'),
        'canRegister' => Route::has('register'),
        'laravelVersion' => Application::VERSION,
        'phpVersion' => PHP_VERSION,
    ]);
});

Route::get('/dashboard', function () {
    return Inertia::render('Dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

Route::post('/webhooks/twilio/voice', [\App\Http\Controllers\TwilioWebhookController::class, 'voice'])->name('webhooks.twilio.voice')->middleware('credits');
Route::post('/webhooks/twilio/status-callback', [\App\Http\Controllers\TwilioWebhookController::class, 'statusCallback'])->name('webhooks.twilio.status-callback');
Route::post('/webhooks/twilio/handle-status', [\App\Http\Controllers\TwilioCallbackController::class, 'handleStatus'])->name('webhooks.twilio.handle-status');

Route::get('/admin/health', [\App\Http\Controllers\HealthCheckController::class, 'index'])->middleware(['auth'])->name('admin.health');

require __DIR__.'/auth.php';
