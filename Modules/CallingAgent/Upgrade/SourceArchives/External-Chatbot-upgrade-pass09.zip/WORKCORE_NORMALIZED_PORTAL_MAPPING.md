# WorkCore Normalized Portal Mapping

This pass updates the chatbot portal bridge to prefer the normalized WorkCore table names:

- clients -> customers
- projects -> service_jobs
- tasks -> checklists
- tickets -> service_issues
- estimates/quotations -> quotes domain

## Runtime compatibility

The portal data service now resolves tables dynamically in this order:

- quotes, then quotations
- service_jobs, then projects
- service_job_time_logs, then project_time_logs
- service_issues, then tickets

## API normalization

Portal API payloads now prefer:

- `service_job_id`
- `service_issue_id`
- `checklist_id`
- `customer_id`

Legacy `project_id` is still mirrored for backward compatibility inside portal action records.
