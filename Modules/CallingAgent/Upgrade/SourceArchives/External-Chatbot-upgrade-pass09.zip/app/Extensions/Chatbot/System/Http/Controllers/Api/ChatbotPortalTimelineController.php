<?php

namespace App\Extensions\Chatbot\System\Http\Controllers\Api;

use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;

class ChatbotPortalTimelineController extends Controller
{
    public function index(int $serviceJobId): JsonResponse
    {
        $timeline = [];

        if (DB::getSchemaBuilder()->hasTable('service_job_time_logs')) {
            $timeline = DB::table('service_job_time_logs')
                ->where('service_job_id', $serviceJobId)
                ->orderByDesc('id')
                ->limit(50)
                ->get();
        }

        return response()->json([
            'timeline' => $timeline
        ]);
    }
}
