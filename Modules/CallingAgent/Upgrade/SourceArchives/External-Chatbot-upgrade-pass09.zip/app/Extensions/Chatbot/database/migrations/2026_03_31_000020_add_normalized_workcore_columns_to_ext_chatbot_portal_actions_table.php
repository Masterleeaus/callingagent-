<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('ext_chatbot_portal_actions', function (Blueprint $table) {
            if (! Schema::hasColumn('ext_chatbot_portal_actions', 'customer_id')) {
                $table->unsignedBigInteger('customer_id')->nullable()->after('company_id');
            }

            if (! Schema::hasColumn('ext_chatbot_portal_actions', 'service_job_id')) {
                $table->unsignedBigInteger('service_job_id')->nullable()->after('quote_id');
            }

            if (! Schema::hasColumn('ext_chatbot_portal_actions', 'service_issue_id')) {
                $table->unsignedBigInteger('service_issue_id')->nullable()->after('service_job_id');
            }

            if (! Schema::hasColumn('ext_chatbot_portal_actions', 'checklist_id')) {
                $table->unsignedBigInteger('checklist_id')->nullable()->after('service_issue_id');
            }
        });
    }

    public function down(): void
    {
        Schema::table('ext_chatbot_portal_actions', function (Blueprint $table) {
            foreach (['customer_id', 'service_job_id', 'service_issue_id', 'checklist_id'] as $column) {
                if (Schema::hasColumn('ext_chatbot_portal_actions', $column)) {
                    $table->dropColumn($column);
                }
            }
        });
    }
};
