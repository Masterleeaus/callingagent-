# Chatbot Portal Upgrade Pass 07

Adds:
- scheduling/visit surface service
- feedback submission endpoint
- site profile retrieval endpoint
- compatibility layer for service_jobs/projects dual schema
