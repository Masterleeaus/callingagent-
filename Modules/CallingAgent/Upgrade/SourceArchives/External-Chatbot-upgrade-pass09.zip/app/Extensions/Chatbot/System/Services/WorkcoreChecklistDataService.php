<?php

namespace App\Extensions\Chatbot\System\Services;

use App\Extensions\Chatbot\System\Support\WorkcoreSchemaMap;
use App\Helpers\Classes\MarketplaceHelper;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

class WorkcoreChecklistDataService
{
    public function forServiceJob(?int $serviceJobId, int $limit = 50): Collection
    {
        if (! $serviceJobId || ! MarketplaceHelper::isRegistered('workcore')) {
            return collect();
        }

        $table = $this->checklistTable();
        if (! $table || ! DB::getSchemaBuilder()->hasTable($table)) {
            return collect();
        }

        $query = DB::table($table);

        foreach (WorkcoreSchemaMap::serviceJobForeignKeys() as $column) {
            if (DB::getSchemaBuilder()->hasColumn($table, $column)) {
                $query->orWhere($column, $serviceJobId);
            }
        }

        return $query->orderByDesc('id')->limit($limit)->get();
    }

    public function summary(?int $serviceJobId): array
    {
        $items = $this->forServiceJob($serviceJobId);

        return [
            'count' => $items->count(),
            'items' => $items,
        ];
    }

    protected function checklistTable(): ?string
    {
        foreach (['checklists', 'tasks'] as $table) {
            if (DB::getSchemaBuilder()->hasTable($table)) {
                return $table;
            }
        }

        return null;
    }
}
