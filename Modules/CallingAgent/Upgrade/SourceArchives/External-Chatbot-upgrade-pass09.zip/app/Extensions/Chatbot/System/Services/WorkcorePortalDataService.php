<?php

namespace App\Extensions\Chatbot\System\Services;

use App\Extensions\Chatbot\System\Models\Chatbot;
use App\Extensions\Chatbot\System\Models\ChatbotCustomer;
use App\Extensions\Chatbot\System\Models\ChatbotPortalBookingRequest;
use App\Extensions\Chatbot\System\Models\ChatbotPortalDocumentLink;
use App\Extensions\Chatbot\System\Support\WorkcoreSchemaMap;
use App\Helpers\Classes\MarketplaceHelper;
use Illuminate\Database\Query\Builder;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

class WorkcorePortalDataService
{
    public function dashboard(Chatbot $chatbot, ?ChatbotCustomer $customer): array
    {
        $bookings = $this->bookings($chatbot, $customer, 5);
        $visits = $this->visits($customer, 5);
        $invoices = $this->invoices($chatbot, $customer, 5);

        return [
            'summary' => [
                'booking_requests' => count($bookings['requests']),
                'quotes' => count($bookings['quotes']),
                'service_jobs' => count($visits['service_jobs']),
                'invoices' => count($invoices['invoices']),
                'documents' => count($invoices['documents']),
            ],
            'bookings' => $bookings,
            'visits' => $visits,
            'invoices' => $invoices,
            'quick_actions' => $this->quickActions($chatbot, $customer),
            'schema' => [
                'quotes_table' => $this->quoteTable(),
                'service_jobs_table' => $this->serviceJobTable(),
                'service_job_time_logs_table' => $this->serviceJobTimeLogTable(),
                'service_issues_table' => $this->serviceIssueTable(),
            ],
        ];
    }

    public function quickActions(Chatbot $chatbot, ?ChatbotCustomer $customer): array
    {
        $quotes = $this->workcoreQuotes($customer, 3);
        $serviceJobs = $this->workcoreServiceJobs($customer, 3);
        $invoices = $this->workcoreInvoices($customer, 3);

        return [
            [
                'type' => 'book_visit',
                'label' => 'Book a visit',
                'status' => 'available',
            ],
            [
                'type' => 'approve_quote',
                'label' => 'Approve quote',
                'status' => $quotes->isEmpty() ? 'hidden' : 'available',
                'quote_id' => $quotes->first()->id ?? null,
            ],
            [
                'type' => 'confirm_service_job',
                'label' => 'Confirm upcoming visit',
                'status' => $serviceJobs->isEmpty() ? 'hidden' : 'available',
                'service_job_id' => $serviceJobs->first()->id ?? null,
            ],
            [
                'type' => 'pay_invoice',
                'label' => 'Pay invoice',
                'status' => $invoices->isEmpty() ? 'hidden' : 'available',
                'invoice_id' => $invoices->first()->id ?? null,
            ],
            [
                'type' => 'request_reclean',
                'label' => 'Request re-clean',
                'status' => 'available',
            ],
        ];
    }

    public function bookings(Chatbot $chatbot, ?ChatbotCustomer $customer, int $limit = 20): array
    {
        $serviceJobs = $this->workcoreServiceJobs($customer, $limit);

        return [
            'requests' => ChatbotPortalBookingRequest::query()
                ->where('chatbot_id', $chatbot->getKey())
                ->when($customer?->getKey(), fn ($query, $customerId) => $query->where('chatbot_customer_id', $customerId))
                ->latest()
                ->limit($limit)
                ->get(),
            'quotes' => $this->workcoreQuotes($customer, $limit),
            'service_jobs' => $serviceJobs,
            'projects' => $serviceJobs,
        ];
    }

    public function visits(?ChatbotCustomer $customer, int $limit = 20): array
    {
        $serviceJobs = $this->workcoreServiceJobs($customer, $limit);
        $timeLogs = $this->workcoreServiceJobTimeLogs($customer, $limit);

        return [
            'service_jobs' => $serviceJobs,
            'service_job_time_logs' => $timeLogs,
            'projects' => $serviceJobs,
            'time_logs' => $timeLogs,
        ];
    }

    public function invoices(Chatbot $chatbot, ?ChatbotCustomer $customer, int $limit = 20): array
    {
        return [
            'invoices' => $this->workcoreInvoices($customer, $limit),
            'documents' => ChatbotPortalDocumentLink::query()
                ->where('chatbot_id', $chatbot->getKey())
                ->when($customer?->getKey(), fn ($query, $customerId) => $query->where('chatbot_customer_id', $customerId))
                ->whereIn('type', ['invoice', 'receipt', 'contract', 'quote'])
                ->latest('published_at')
                ->limit($limit)
                ->get(),
        ];
    }

    public function serviceIssues(Chatbot $chatbot, ?ChatbotCustomer $customer, int $limit = 20): array
    {
        return [
            'service_issues' => $this->workcoreServiceIssues($customer, $limit),
            'open_reclean_requests' => ChatbotPortalDocumentLink::query()
                ->where('chatbot_id', $chatbot->getKey())
                ->when($customer?->getKey(), fn ($query, $customerId) => $query->where('chatbot_customer_id', $customerId))
                ->where('type', 'service_issue')
                ->latest('id')
                ->limit($limit)
                ->get(),
        ];
    }

    protected function workcoreQuotes(?ChatbotCustomer $customer, int $limit): Collection
    {
        $table = $this->quoteTable();
        if (! $table) {
            return collect();
        }

        return $this->forCustomer(DB::table($table), $table, $customer)
            ->orderByDesc($table . '.id')
            ->limit($limit)
            ->get();
    }

    protected function workcoreServiceJobs(?ChatbotCustomer $customer, int $limit): Collection
    {
        $table = $this->serviceJobTable();
        if (! $table) {
            return collect();
        }

        return $this->forCustomer(DB::table($table), $table, $customer)
            ->orderByDesc($table . '.id')
            ->limit($limit)
            ->get();
    }

    protected function workcoreServiceJobTimeLogs(?ChatbotCustomer $customer, int $limit): Collection
    {
        $timeLogTable = $this->serviceJobTimeLogTable();
        $serviceJobTable = $this->serviceJobTable();

        if (! $timeLogTable) {
            return collect();
        }

        $query = DB::table($timeLogTable);

        if ($customer?->getKey() && $serviceJobTable) {
            $jobIdColumn = DB::getSchemaBuilder()->hasColumn($timeLogTable, 'service_job_id')
                ? 'service_job_id'
                : (DB::getSchemaBuilder()->hasColumn($timeLogTable, 'project_id') ? 'project_id' : null);

            if ($jobIdColumn) {
                $query->join($serviceJobTable, $serviceJobTable . '.id', '=', $timeLogTable . '.' . $jobIdColumn);
                $query = $this->forCustomer($query, $serviceJobTable, $customer);
                $query->select($timeLogTable . '.*');
            }
        }

        return $query->orderByDesc($timeLogTable . '.id')
            ->limit($limit)
            ->get();
    }

    protected function workcoreInvoices(?ChatbotCustomer $customer, int $limit): Collection
    {
        if (! $this->tableExists('invoices')) {
            return collect();
        }

        return $this->forCustomer(DB::table('invoices'), 'invoices', $customer)
            ->orderByDesc('invoices.id')
            ->limit($limit)
            ->get();
    }

    protected function workcoreServiceIssues(?ChatbotCustomer $customer, int $limit): Collection
    {
        $table = $this->serviceIssueTable();
        if (! $table) {
            return collect();
        }

        return $this->forCustomer(DB::table($table), $table, $customer)
            ->orderByDesc($table . '.id')
            ->limit($limit)
            ->get();
    }

    protected function forCustomer(Builder $query, string $table, ?ChatbotCustomer $customer): Builder
    {
        if (! $customer?->getKey()) {
            return $query;
        }

        $query->where(function ($subQuery) use ($table, $customer) {
            foreach (WorkcoreSchemaMap::customerForeignKeys() as $column) {
                if (DB::getSchemaBuilder()->hasColumn($table, $column)) {
                    $subQuery->orWhere($table . '.' . $column, $customer->getKey());
                }
            }
        });

        return $query;
    }

    protected function quoteTable(): ?string
    {
        return WorkcoreSchemaMap::firstExistingTable(
            WorkcoreSchemaMap::quoteTables(),
            fn (string $table) => $this->tableExists($table)
        );
    }

    protected function serviceJobTable(): ?string
    {
        return WorkcoreSchemaMap::firstExistingTable(
            WorkcoreSchemaMap::serviceJobTables(),
            fn (string $table) => $this->tableExists($table)
        );
    }

    protected function serviceJobTimeLogTable(): ?string
    {
        return WorkcoreSchemaMap::firstExistingTable(
            WorkcoreSchemaMap::serviceJobTimeLogTables(),
            fn (string $table) => $this->tableExists($table)
        );
    }

    protected function serviceIssueTable(): ?string
    {
        return WorkcoreSchemaMap::firstExistingTable(
            WorkcoreSchemaMap::serviceIssueTables(),
            fn (string $table) => $this->tableExists($table)
        );
    }

    protected function tableExists(string $table): bool
    {
        return MarketplaceHelper::isRegistered('workcore')
            && DB::getSchemaBuilder()->hasTable($table);
    }
}
