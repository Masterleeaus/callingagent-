# Chatbot Portal Upgrade Pass 05

Added a compatibility-first normalization layer for the updated WorkCore schema.

## Key changes
- prefers `service_jobs` over `projects`
- prefers `service_job_time_logs` over `project_time_logs`
- prefers `service_issues` over `tickets`
- keeps fallback support for legacy tables
- action queue now accepts `service_job_id`, `service_issue_id`, `checklist_id`, and `customer_id`

## Outcome
The chatbot portal can now align to the renamed cleaning vertical schema without losing backward compatibility with older WorkCore installs.
