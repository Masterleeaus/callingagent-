# Chatbot Portal Upgrade Pass 08

Added:
- finished-widget menu endpoint
- finished-widget home/cards endpoint
- user-facing menu sections for bookings, quotes, invoices, feedback, property, visit history, recurring service, support, and channels
- full repair of ChatbotServiceProvider route registration after previous malformed route append

This pass defines the actual end-user widget navigation contract rather than only backend bridge records.
