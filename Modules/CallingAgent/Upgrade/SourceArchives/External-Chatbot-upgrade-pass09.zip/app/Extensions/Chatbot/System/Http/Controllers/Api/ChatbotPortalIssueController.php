<?php

namespace App\Extensions\Chatbot\System\Http\Controllers\Api;

use App\Extensions\Chatbot\System\Models\Chatbot;
use App\Extensions\Chatbot\System\Models\ChatbotCustomer;
use App\Extensions\Chatbot\System\Services\WorkcorePortalDataService;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;

class ChatbotPortalIssueController extends Controller
{
    public function __construct(protected WorkcorePortalDataService $dataService)
    {
    }

    public function index(Chatbot $chatbot, string $sessionId): JsonResponse
    {
        $customer = $this->customer($chatbot, $sessionId);

        return response()->json(array_merge(
            $this->dataService->serviceIssues($chatbot, $customer),
            [
                'quick_actions' => $this->dataService->quickActions($chatbot, $customer),
            ]
        ));
    }

    protected function customer(Chatbot $chatbot, string $sessionId): ?ChatbotCustomer
    {
        return ChatbotCustomer::query()
            ->where('chatbot_id', $chatbot->getKey())
            ->where(function ($query) use ($sessionId) {
                $query->where('payload->session_id', $sessionId)
                    ->orWhere('email', $sessionId);
            })
            ->latest('id')
            ->first();
    }
}
