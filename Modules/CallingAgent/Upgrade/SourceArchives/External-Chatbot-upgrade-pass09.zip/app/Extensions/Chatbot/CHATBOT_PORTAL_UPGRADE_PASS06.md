# Chatbot Portal Upgrade Pass 06

Added:
- service issues API endpoint
- service job checklist API endpoint
- action planning service for queued portal actions
- richer quick action responses with execution plans

Reuse-first mapping:
- service_issues -> complaint / re-clean / issue center
- checklists -> service job task/checklist surface
- service_jobs -> visit-level checklist lookup
- queued actions remain non-destructive until downstream handlers execute
