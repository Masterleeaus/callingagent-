<?php

namespace App\Extensions\Chatbot\System\Services;

use App\Helpers\Classes\MarketplaceHelper;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

class WorkcoreSchedulingDataService
{
    public function upcomingVisits(?int $customerId, int $limit = 10): Collection
    {
        if (! MarketplaceHelper::isRegistered('workcore')) {
            return collect();
        }

        foreach (['service_jobs', 'projects'] as $table) {
            if (DB::getSchemaBuilder()->hasTable($table)) {
                $query = DB::table($table);

                if ($customerId) {
                    foreach (['customer_id','client_id','user_id'] as $col) {
                        if (DB::getSchemaBuilder()->hasColumn($table,$col)) {
                            $query->orWhere($col,$customerId);
                        }
                    }
                }

                return $query->orderByDesc('id')->limit($limit)->get();
            }
        }

        return collect();
    }
}
