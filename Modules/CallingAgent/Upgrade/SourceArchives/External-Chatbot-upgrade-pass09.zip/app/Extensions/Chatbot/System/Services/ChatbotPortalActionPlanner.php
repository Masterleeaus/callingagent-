<?php

namespace App\Extensions\Chatbot\System\Services;

use App\Extensions\Chatbot\System\Models\ChatbotPortalAction;

class ChatbotPortalActionPlanner
{
    public function present(ChatbotPortalAction $action): array
    {
        return match ($action->type) {
            'approve_quote' => [
                'title' => 'Approve quote',
                'target' => 'quotes',
                'status' => $action->status,
                'next_step' => 'Send to quote approval handler',
            ],
            'confirm_service_job', 'confirm_visit' => [
                'title' => 'Confirm upcoming visit',
                'target' => 'service_jobs',
                'status' => $action->status,
                'next_step' => 'Send to service job confirmation handler',
            ],
            'pay_invoice' => [
                'title' => 'Pay invoice',
                'target' => 'invoices',
                'status' => $action->status,
                'next_step' => 'Redirect to payment handler',
            ],
            'request_reclean' => [
                'title' => 'Request re-clean',
                'target' => 'service_issues',
                'status' => $action->status,
                'next_step' => 'Open service issue or workflow',
            ],
            default => [
                'title' => $action->label ?: $action->type,
                'target' => 'portal',
                'status' => $action->status,
                'next_step' => 'Review manually',
            ],
        };
    }
}
