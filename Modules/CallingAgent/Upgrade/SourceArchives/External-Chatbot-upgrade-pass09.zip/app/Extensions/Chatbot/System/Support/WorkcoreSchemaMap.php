<?php

namespace App\Extensions\Chatbot\System\Support;

class WorkcoreSchemaMap
{
    public static function firstExistingTable(array $tables, callable $resolver): ?string
    {
        foreach ($tables as $table) {
            if ($resolver($table)) {
                return $table;
            }
        }

        return null;
    }

    public static function customerTables(): array
    {
        return ['customer_details', 'client_details'];
    }

    public static function quoteTables(): array
    {
        return ['quotes', 'quotations'];
    }

    public static function serviceJobTables(): array
    {
        return ['service_jobs', 'projects'];
    }

    public static function serviceJobTimeLogTables(): array
    {
        return ['service_job_time_logs', 'project_time_logs'];
    }

    public static function serviceIssueTables(): array
    {
        return ['service_issues', 'tickets'];
    }

    public static function customerForeignKeys(): array
    {
        return ['customer_id', 'client_id', 'user_id'];
    }

    public static function serviceJobForeignKeys(): array
    {
        return ['service_job_id', 'project_id'];
    }
}
