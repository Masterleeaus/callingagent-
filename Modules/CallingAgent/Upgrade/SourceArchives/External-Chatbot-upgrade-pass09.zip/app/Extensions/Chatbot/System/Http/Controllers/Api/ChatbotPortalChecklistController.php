<?php

namespace App\Extensions\Chatbot\System\Http\Controllers\Api;

use App\Extensions\Chatbot\System\Services\WorkcoreChecklistDataService;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;

class ChatbotPortalChecklistController extends Controller
{
    public function __construct(protected WorkcoreChecklistDataService $dataService)
    {
    }

    public function index(int $serviceJobId): JsonResponse
    {
        return response()->json($this->dataService->summary($serviceJobId));
    }
}
