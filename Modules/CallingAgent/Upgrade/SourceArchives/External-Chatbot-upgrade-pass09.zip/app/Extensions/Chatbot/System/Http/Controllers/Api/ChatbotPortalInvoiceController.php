<?php

namespace App\Extensions\Chatbot\System\Http\Controllers\Api;

use App\Extensions\Chatbot\System\Models\Chatbot;
use App\Extensions\Chatbot\System\Models\ChatbotCustomer;
use App\Extensions\Chatbot\System\Services\WorkcorePortalDataService;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;

class ChatbotPortalInvoiceController extends Controller
{
    public function __construct(protected WorkcorePortalDataService $dataService)
    {
    }

    public function index(Chatbot $chatbot, string $sessionId): JsonResponse
    {
        $customer = ChatbotCustomer::query()
            ->where('chatbot_id', $chatbot->getKey())
            ->where('session_id', $sessionId)
            ->first();

        return response()->json(array_merge($this->dataService->invoices($chatbot, $customer), [
            'quick_actions' => $this->dataService->quickActions($chatbot, $customer),
        ]));
    }
}
