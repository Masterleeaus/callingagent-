<?php

namespace App\Extensions\Chatbot\System\Services;

class ChatbotWidgetMenuService
{
    public function default(): array
    {
        return [
            'book_visit',
            'approve_quote',
            'pay_invoice',
            'leave_feedback',
            'my_property',
            'visit_history',
            'documents',
            'support',
        ];
    }
}
