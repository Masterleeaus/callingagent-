<?php

namespace App\Extensions\Chatbot\System\Http\Controllers\Api;

use Illuminate\Http\JsonResponse;
use App\Http\Controllers\Controller;

class ChatbotPortalPaymentController extends Controller
{
    public function redirect(int $invoiceId): JsonResponse
    {
        return response()->json([
            'invoice_id' => $invoiceId,
            'payment_url' => route('payment.process', ['invoice' => $invoiceId]),
        ]);
    }
}
