<?php

namespace App\Extensions\Chatbot\System\Http\Controllers\Api;

use App\Extensions\Chatbot\System\Models\ChatbotPortalFeedback;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;

class ChatbotPortalFeedbackController extends Controller
{
    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'customer_id' => ['nullable','integer'],
            'service_job_id' => ['nullable','integer'],
            'rating' => ['nullable','integer'],
            'notes' => ['nullable','string']
        ]);

        $feedback = ChatbotPortalFeedback::query()->create($validated);

        return response()->json([
            'message' => 'Feedback stored',
            'feedback' => $feedback
        ],201);
    }
}
