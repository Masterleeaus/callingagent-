<?php

namespace App\Extensions\Chatbot\System\Http\Controllers\Api;

use App\Extensions\Chatbot\System\Models\ChatbotPortalDocumentLink;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;

class ChatbotPortalDocumentVaultController extends Controller
{
    public function index(int $customerId): JsonResponse
    {
        return response()->json([
            'documents' => ChatbotPortalDocumentLink::query()
                ->where('chatbot_customer_id', $customerId)
                ->latest('published_at')
                ->limit(50)
                ->get(),
        ]);
    }
}
