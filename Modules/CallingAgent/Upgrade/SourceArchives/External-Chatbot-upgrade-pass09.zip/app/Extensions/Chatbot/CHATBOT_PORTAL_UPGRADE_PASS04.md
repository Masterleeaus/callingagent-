# Chatbot Portal Upgrade Pass 04

Added:
- dashboard API endpoint
- quick-action API endpoint
- portal actions table/model
- action queue support for:
  - approve quote
  - confirm visit
  - pay invoice
  - request re-clean
  - book visit

Reuse-first mapping:
- quotes -> approvals
- projects -> visit confirmations
- invoices -> payment actions
- tickets/feedback -> re-clean workflow

This pass keeps execution non-destructive by queuing customer actions
into extension-owned portal tables for downstream approval/processing.


## Pass 05 follow-up
- normalized WorkCore table support added
- service_jobs/service_issues/checklists terminology preferred in APIs
- legacy projects/tickets compatibility retained
