<?php

namespace App\Extensions\Chatbot\System\Services;

use App\Extensions\Chatbot\System\Models\Chatbot;
use App\Extensions\Chatbot\System\Models\ChatbotCustomer;

class ChatbotPortalWidgetMenuService
{
    public function build(Chatbot $chatbot, ?ChatbotCustomer $customer, array $dashboard = []): array
    {
        $quickActions = $dashboard['quick_actions'] ?? [];
        $summary = $dashboard['summary'] ?? [];

        return [
            'layout' => [
                'version' => 'portal-widget-v1',
                'default_tab' => 'home',
                'tabs' => [
                    ['key' => 'home', 'label' => 'Home', 'icon' => 'home'],
                    ['key' => 'chat', 'label' => 'Chat', 'icon' => 'message-circle'],
                    ['key' => 'help', 'label' => 'Help', 'icon' => 'life-buoy'],
                ],
            ],
            'hero' => [
                'title' => 'How can we help?',
                'subtitle' => 'Customer portal shortcuts inside chat.',
                'primary_actions' => $this->primaryActions($quickActions),
            ],
            'sections' => [
                $this->section('bookings', 'Bookings', [
                    $this->link('book_visit', 'Book a visit', 'portal_action', ['type' => 'book_visit']),
                    $this->link('reschedule_visit', 'Reschedule visit', 'chat_prompt', ['prompt' => 'I need to reschedule my visit']),
                    $this->link('skip_visit', 'Skip next visit', 'chat_prompt', ['prompt' => 'I need to skip my next visit']),
                    $this->link('pause_service', 'Pause recurring service', 'chat_prompt', ['prompt' => 'I need to pause my recurring service']),
                ], ['count' => $summary['booking_requests'] ?? 0]),
                $this->section('quotes', 'Quotes', [
                    $this->link('view_quotes', 'View quote', 'screen', ['screen' => 'quotes']),
                    $this->link('approve_quote', 'Approve quote', 'portal_action', ['type' => 'approve_quote']),
                    $this->link('request_quote_changes', 'Request changes', 'chat_prompt', ['prompt' => 'I want changes to my quote']),
                    $this->link('quote_question', 'Ask about quote', 'chat_prompt', ['prompt' => 'I have a question about my quote']),
                ], ['count' => $summary['quotes'] ?? 0]),
                $this->section('invoices', 'Invoices', [
                    $this->link('view_invoices', 'View invoice', 'screen', ['screen' => 'invoices']),
                    $this->link('pay_invoice', 'Pay invoice', 'portal_action', ['type' => 'pay_invoice']),
                    $this->link('download_receipt', 'Download receipt', 'screen', ['screen' => 'documents', 'filter' => 'receipt']),
                    $this->link('payment_history', 'Payment history', 'screen', ['screen' => 'invoices', 'view' => 'history']),
                ], ['count' => $summary['invoices'] ?? 0]),
                $this->section('feedback', 'Feedback', [
                    $this->link('rate_last_visit', 'Rate last visit', 'screen', ['screen' => 'feedback']),
                    $this->link('leave_feedback', 'Leave feedback', 'screen', ['screen' => 'feedback', 'mode' => 'new']),
                    $this->link('request_reclean', 'Request re-clean', 'portal_action', ['type' => 'request_reclean']),
                ]),
                $this->section('property', 'My Property', [
                    $this->link('site_profile', 'Access instructions', 'screen', ['screen' => 'site_profile']),
                    $this->link('parking_notes', 'Parking notes', 'screen', ['screen' => 'site_profile', 'field' => 'parking']),
                    $this->link('pet_notes', 'Pet notes', 'screen', ['screen' => 'site_profile', 'field' => 'pets']),
                    $this->link('update_preferences', 'Update preferences', 'chat_prompt', ['prompt' => 'I need to update my property preferences']),
                ]),
                $this->section('history', 'Visit History', [
                    $this->link('past_visits', 'Past visits', 'screen', ['screen' => 'visits']),
                    $this->link('cleaner_notes', 'Cleaner notes', 'screen', ['screen' => 'visits', 'view' => 'notes']),
                    $this->link('checklist_results', 'Checklist results', 'screen', ['screen' => 'checklists']),
                    $this->link('before_after', 'Before/after photos', 'screen', ['screen' => 'documents', 'filter' => 'visit_media']),
                ], ['count' => $summary['service_jobs'] ?? ($summary['visits'] ?? 0)]),
                $this->section('recurring', 'Recurring Service', [
                    $this->link('change_frequency', 'Change frequency', 'chat_prompt', ['prompt' => 'I want to change my service frequency']),
                    $this->link('add_extras', 'Add extras', 'chat_prompt', ['prompt' => 'I want to add extras to my service']),
                    $this->link('skip_next', 'Skip next visit', 'chat_prompt', ['prompt' => 'Please skip my next visit']),
                    $this->link('pause_recurring', 'Pause service', 'chat_prompt', ['prompt' => 'Please pause my recurring service']),
                ]),
                $this->section('support', 'Support', [
                    $this->link('report_issue', 'Report an issue', 'screen', ['screen' => 'issues']),
                    $this->link('billing_question', 'Ask billing question', 'chat_prompt', ['prompt' => 'I have a billing question']),
                    $this->link('general_help', 'General help', 'chat_prompt', ['prompt' => 'I need help']),
                ]),
                $this->channelsSection($chatbot),
            ],
            'customer' => [
                'id' => $customer?->getKey(),
                'name' => $customer?->name,
                'email' => $customer?->email,
            ],
        ];
    }

    protected function primaryActions(array $quickActions): array
    {
        $defaults = [
            ['type' => 'book_visit', 'label' => 'Book a Visit'],
            ['type' => 'approve_quote', 'label' => 'Approve Quote'],
            ['type' => 'pay_invoice', 'label' => 'Pay Invoice'],
            ['type' => 'request_reclean', 'label' => 'Request Re-clean'],
        ];

        $available = [];
        foreach ($defaults as $default) {
            foreach ($quickActions as $quickAction) {
                if (($quickAction['type'] ?? null) === $default['type'] && ($quickAction['status'] ?? 'available') !== 'hidden') {
                    $available[] = [
                        'type' => $default['type'],
                        'label' => $quickAction['label'] ?? $default['label'],
                    ];
                    break;
                }
            }
        }

        return $available ?: $defaults;
    }

    protected function channelsSection(Chatbot $chatbot): array
    {
        $links = [];
        foreach ([
            'whatsapp_link' => 'WhatsApp',
            'telegram_link' => 'Telegram',
            'facebook_link' => 'Messenger',
            'instagram_link' => 'Instagram',
        ] as $field => $label) {
            $url = $chatbot->getAttribute($field);
            if ($url) {
                $links[] = $this->link(strtolower($label), $label, 'external_url', ['url' => $url]);
            }
        }

        return $this->section('channels', 'Channels', $links ?: [
            $this->link('web_chat', 'Use chat', 'screen', ['screen' => 'chat'])
        ]);
    }

    protected function section(string $key, string $label, array $links, array $meta = []): array
    {
        return [
            'key' => $key,
            'label' => $label,
            'links' => $links,
            'meta' => $meta,
        ];
    }

    protected function link(string $key, string $label, string $action, array $payload = []): array
    {
        return [
            'key' => $key,
            'label' => $label,
            'action' => $action,
            'payload' => $payload,
        ];
    }
}
