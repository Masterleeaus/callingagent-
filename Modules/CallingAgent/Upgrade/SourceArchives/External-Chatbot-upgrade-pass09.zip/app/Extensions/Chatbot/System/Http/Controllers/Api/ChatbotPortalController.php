<?php

namespace App\Extensions\Chatbot\System\Http\Controllers\Api;

use App\Extensions\Chatbot\System\Models\Chatbot;
use App\Extensions\Chatbot\System\Models\ChatbotCustomer;
use App\Extensions\Chatbot\System\Models\ChatbotPortalFeedback;
use App\Extensions\Chatbot\System\Models\ChatbotPortalNotification;
use App\Extensions\Chatbot\System\Models\ChatbotPortalRecurringService;
use App\Extensions\Chatbot\System\Models\ChatbotPortalSiteProfile;
use App\Helpers\Classes\MarketplaceHelper;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use App\Extensions\Chatbot\System\Services\WorkcorePortalDataService;
use Illuminate\Support\Facades\DB;

class ChatbotPortalController extends Controller
{
    public function __construct(protected WorkcorePortalDataService $dataService)
    {
    }
    public function overview(Chatbot $chatbot, string $sessionId): JsonResponse
    {
        $customer = $this->customer($chatbot, $sessionId);
        $customerId = $customer?->getKey();

        $siteProfiles = ChatbotPortalSiteProfile::query()
            ->where('chatbot_id', $chatbot->getKey())
            ->when($customerId, fn ($query) => $query->where('chatbot_customer_id', $customerId))
            ->orderBy('site_label')
            ->get([
                'id',
                'site_id',
                'site_label',
                'entry_method',
                'priority_rooms',
                'preferences',
            ]);

        $recurringServices = ChatbotPortalRecurringService::query()
            ->where('chatbot_id', $chatbot->getKey())
            ->when($customerId, fn ($query) => $query->where('chatbot_customer_id', $customerId))
            ->orderBy('next_service_date')
            ->get([
                'id',
                'site_id',
                'service_name',
                'frequency',
                'next_service_date',
                'is_paused',
                'extras',
            ]);

        $notifications = ChatbotPortalNotification::query()
            ->where('chatbot_id', $chatbot->getKey())
            ->when($customerId, fn ($query) => $query->where('chatbot_customer_id', $customerId))
            ->latest()
            ->limit(10)
            ->get([
                'id',
                'type',
                'title',
                'body',
                'action_label',
                'action_url',
                'payload',
                'read_at',
                'sent_at',
                'created_at',
            ]);

        return response()->json([
            'enabled' => (bool) $chatbot->getAttribute('is_customer_portal'),
            'dashboard' => $this->dataService->dashboard($chatbot, $customer),
            'home_title' => $chatbot->getAttribute('portal_home_title') ?: 'Customer portal',
            'primary_cta' => $chatbot->getAttribute('portal_primary_cta') ?: 'Book visit',
            'modules' => $chatbot->getAttribute('portal_modules') ?: [
                'dashboard',
                'bookings',
                'visits',
                'invoices',
                'feedback',
                'help',
            ],
            'nav_items' => $chatbot->getAttribute('portal_nav_items') ?: [
                ['key' => 'home', 'label' => 'Home'],
                ['key' => 'chat', 'label' => 'Chat'],
                ['key' => 'documents', 'label' => 'Docs'],
                ['key' => 'help', 'label' => 'Help'],
            ],
            'quick_actions' => $chatbot->getAttribute('portal_quick_actions') ?: [
                ['key' => 'book_visit', 'label' => 'Book visit'],
                ['key' => 'reschedule', 'label' => 'Reschedule'],
                ['key' => 'pay_invoice', 'label' => 'Pay invoice'],
                ['key' => 'request_reclean', 'label' => 'Request re-clean'],
            ],
            'customer' => [
                'id' => $customer?->getKey(),
                'name' => $customer?->getAttribute('name'),
                'email' => $customer?->getAttribute('email'),
                'phone' => $customer?->getAttribute('phone'),
            ],
            'stats' => $this->stats($customerId),
            'site_profiles' => $siteProfiles,
            'recurring_services' => $recurringServices,
            'notifications' => $notifications,
            'help_center_title' => $chatbot->getAttribute('portal_help_center_title') ?: 'Help center',
            'document_title' => $chatbot->getAttribute('portal_document_title') ?: 'Documents',
        ]);
    }

    public function notifications(Chatbot $chatbot, string $sessionId): JsonResponse
    {
        $customer = $this->customer($chatbot, $sessionId);

        $notifications = ChatbotPortalNotification::query()
            ->where('chatbot_id', $chatbot->getKey())
            ->when($customer?->getKey(), fn ($query, $customerId) => $query->where('chatbot_customer_id', $customerId))
            ->latest()
            ->paginate(20);

        return response()->json($notifications);
    }

    public function markNotificationRead(Chatbot $chatbot, string $sessionId, ChatbotPortalNotification $notification): JsonResponse
    {
        $customer = $this->customer($chatbot, $sessionId);

        abort_unless($notification->chatbot_id === $chatbot->getKey(), 404);
        abort_if($customer && $notification->chatbot_customer_id && $notification->chatbot_customer_id !== $customer->getKey(), 403);

        $notification->forceFill(['read_at' => now()])->save();

        return response()->json([
            'message' => 'Notification marked as read.',
            'data' => $notification->fresh(),
        ]);
    }

    public function storeSiteProfile(Request $request, Chatbot $chatbot, string $sessionId): JsonResponse
    {
        $customer = $this->customer($chatbot, $sessionId);

        $validated = $request->validate([
            'company_id' => ['nullable', 'integer'],
            'site_id' => ['nullable', 'integer'],
            'site_label' => ['nullable', 'string', 'max:255'],
            'entry_method' => ['nullable', 'string', 'max:255'],
            'access_notes' => ['nullable', 'string'],
            'parking_notes' => ['nullable', 'string'],
            'pet_notes' => ['nullable', 'string'],
            'priority_rooms' => ['nullable', 'string'],
            'preferences' => ['nullable', 'array'],
            'media' => ['nullable', 'array'],
        ]);

        $profile = ChatbotPortalSiteProfile::query()->updateOrCreate([
            'chatbot_id' => $chatbot->getKey(),
            'chatbot_customer_id' => $customer?->getKey(),
            'site_id' => $validated['site_id'] ?? null,
        ], array_merge($validated, [
            'chatbot_id' => $chatbot->getKey(),
            'chatbot_customer_id' => $customer?->getKey(),
        ]));

        return response()->json([
            'message' => 'Site profile saved.',
            'data' => $profile,
        ], 201);
    }

    public function storeRecurringService(Request $request, Chatbot $chatbot, string $sessionId): JsonResponse
    {
        $customer = $this->customer($chatbot, $sessionId);

        $validated = $request->validate([
            'company_id' => ['nullable', 'integer'],
            'site_id' => ['nullable', 'integer'],
            'quote_id' => ['nullable', 'integer'],
            'project_id' => ['nullable', 'integer'],
            'service_name' => ['required', 'string', 'max:255'],
            'frequency' => ['nullable', 'string', 'max:255'],
            'next_service_date' => ['nullable', 'date'],
            'is_paused' => ['nullable', 'boolean'],
            'paused_until' => ['nullable', 'date'],
            'extras' => ['nullable', 'array'],
            'rules' => ['nullable', 'array'],
        ]);

        $service = ChatbotPortalRecurringService::query()->create([
            'chatbot_id' => $chatbot->getKey(),
            'chatbot_customer_id' => $customer?->getKey(),
            'company_id' => $validated['company_id'] ?? null,
            'site_id' => $validated['site_id'] ?? null,
            'quote_id' => $validated['quote_id'] ?? null,
            'project_id' => $validated['project_id'] ?? null,
            'service_name' => $validated['service_name'],
            'frequency' => $validated['frequency'] ?? null,
            'next_service_date' => $validated['next_service_date'] ?? null,
            'is_paused' => $validated['is_paused'] ?? false,
            'paused_until' => $validated['paused_until'] ?? null,
            'extras' => $validated['extras'] ?? null,
            'rules' => $validated['rules'] ?? null,
        ]);

        return response()->json([
            'message' => 'Recurring service saved.',
            'data' => $service,
        ], 201);
    }

    public function storeFeedback(Request $request, Chatbot $chatbot, string $sessionId): JsonResponse
    {
        $customer = $this->customer($chatbot, $sessionId);

        $validated = $request->validate([
            'conversation_id' => ['nullable', 'integer'],
            'site_id' => ['nullable', 'integer'],
            'project_id' => ['nullable', 'integer'],
            'invoice_id' => ['nullable', 'integer'],
            'ticket_id' => ['nullable', 'integer'],
            'rating' => ['nullable', 'integer', 'between:1,5'],
            'status' => ['nullable', 'string', 'max:50'],
            'is_reclean_request' => ['nullable', 'boolean'],
            'feedback' => ['nullable', 'string'],
            'attachments' => ['nullable', 'array'],
            'resolution_events' => ['nullable', 'array'],
        ]);

        $feedback = ChatbotPortalFeedback::query()->create([
            'chatbot_id' => $chatbot->getKey(),
            'chatbot_customer_id' => $customer?->getKey(),
            'conversation_id' => $validated['conversation_id'] ?? null,
            'site_id' => $validated['site_id'] ?? null,
            'project_id' => $validated['project_id'] ?? null,
            'invoice_id' => $validated['invoice_id'] ?? null,
            'ticket_id' => $validated['ticket_id'] ?? null,
            'rating' => $validated['rating'] ?? null,
            'status' => $validated['status'] ?? 'open',
            'is_reclean_request' => $validated['is_reclean_request'] ?? false,
            'feedback' => $validated['feedback'] ?? null,
            'attachments' => $validated['attachments'] ?? null,
            'resolution_events' => $validated['resolution_events'] ?? null,
        ]);

        return response()->json([
            'message' => 'Portal feedback created.',
            'data' => $feedback,
        ], 201);
    }

    protected function customer(Chatbot $chatbot, string $sessionId): ?ChatbotCustomer
    {
        return ChatbotCustomer::query()
            ->where('chatbot_id', $chatbot->getKey())
            ->where('session_id', $sessionId)
            ->first();
    }

    protected function stats(?int $customerId): array
    {
        $stats = [
            'open_feedback_items' => 0,
            'unread_notifications' => 0,
            'pending_invoices' => 0,
        ];

        if (! $customerId) {
            return $stats;
        }

        $stats['open_feedback_items'] = ChatbotPortalFeedback::query()
            ->where('chatbot_customer_id', $customerId)
            ->where('status', '!=', 'resolved')
            ->count();

        $stats['unread_notifications'] = ChatbotPortalNotification::query()
            ->where('chatbot_customer_id', $customerId)
            ->whereNull('read_at')
            ->count();

        if (MarketplaceHelper::isRegistered('workcore') && DB::getSchemaBuilder()->hasTable('invoices')) {
            $stats['pending_invoices'] = DB::table('invoices')
                ->where(function ($query) use ($customerId) {
                    foreach (['client_id', 'user_id', 'customer_id'] as $column) {
                        if (DB::getSchemaBuilder()->hasColumn('invoices', $column)) {
                            $query->orWhere($column, $customerId);
                        }
                    }
                })
                ->whereIn('status', ['unpaid', 'partial'])
                ->count();
        }

        return $stats;
    }
}
