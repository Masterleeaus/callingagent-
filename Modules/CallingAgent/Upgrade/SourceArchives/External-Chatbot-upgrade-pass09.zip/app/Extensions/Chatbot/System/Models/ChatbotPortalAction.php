<?php

namespace App\Extensions\Chatbot\System\Models;

use Illuminate\Database\Eloquent\Model;

class ChatbotPortalAction extends Model
{
    protected $table = 'ext_chatbot_portal_actions';

    protected $guarded = [];

    protected $casts = [
        'payload' => 'array',
        'requested_at' => 'datetime',
        'processed_at' => 'datetime',
    ];
}
