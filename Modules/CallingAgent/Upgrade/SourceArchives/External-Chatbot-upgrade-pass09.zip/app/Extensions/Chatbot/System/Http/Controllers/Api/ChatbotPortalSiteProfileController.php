<?php

namespace App\Extensions\Chatbot\System\Http\Controllers\Api;

use App\Extensions\Chatbot\System\Models\ChatbotPortalSiteProfile;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;

class ChatbotPortalSiteProfileController extends Controller
{
    public function show(int $siteId): JsonResponse
    {
        $profile = ChatbotPortalSiteProfile::query()
            ->where('site_id',$siteId)
            ->first();

        return response()->json([
            'site_profile'=>$profile
        ]);
    }
}
