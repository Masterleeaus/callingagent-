<?php

namespace App\Extensions\Chatbot\System\Http\Controllers\Api;

use App\Extensions\Chatbot\System\Models\Chatbot;
use App\Extensions\Chatbot\System\Models\ChatbotCustomer;
use App\Extensions\Chatbot\System\Services\WorkcorePortalDataService;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;

class ChatbotPortalHomeController extends Controller
{
    public function __construct(protected WorkcorePortalDataService $portalDataService)
    {
    }

    public function show(Chatbot $chatbot, string $sessionId): JsonResponse
    {
        $customer = $this->customer($chatbot, $sessionId);
        $dashboard = $this->portalDataService->dashboard($chatbot, $customer);

        return response()->json([
            'cards' => [
                [
                    'key' => 'next_visit',
                    'label' => 'Next visit',
                    'value' => count($dashboard['visits']['service_jobs'] ?? $dashboard['visits']['projects'] ?? []),
                    'screen' => 'visits',
                ],
                [
                    'key' => 'outstanding_invoices',
                    'label' => 'Outstanding invoices',
                    'value' => count($dashboard['invoices']['invoices'] ?? []),
                    'screen' => 'invoices',
                ],
                [
                    'key' => 'documents',
                    'label' => 'Documents',
                    'value' => count($dashboard['invoices']['documents'] ?? []),
                    'screen' => 'documents',
                ],
                [
                    'key' => 'quotes',
                    'label' => 'Quotes',
                    'value' => count($dashboard['bookings']['quotes'] ?? []),
                    'screen' => 'quotes',
                ],
            ],
            'dashboard' => $dashboard,
        ]);
    }

    protected function customer(Chatbot $chatbot, string $sessionId): ?ChatbotCustomer
    {
        return ChatbotCustomer::query()
            ->where('chatbot_id', $chatbot->getKey())
            ->where(function ($query) use ($sessionId) {
                $query->where('payload->session_id', $sessionId)
                    ->orWhere('email', $sessionId);
            })
            ->latest('id')
            ->first();
    }
}
