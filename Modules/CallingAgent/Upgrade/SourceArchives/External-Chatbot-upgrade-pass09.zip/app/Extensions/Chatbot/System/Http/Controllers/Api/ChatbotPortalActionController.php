<?php

namespace App\Extensions\Chatbot\System\Http\Controllers\Api;

use App\Extensions\Chatbot\System\Models\Chatbot;
use App\Extensions\Chatbot\System\Models\ChatbotConversation;
use App\Extensions\Chatbot\System\Models\ChatbotCustomer;
use App\Extensions\Chatbot\System\Models\ChatbotPortalAction;
use App\Extensions\Chatbot\System\Services\ChatbotPortalActionPlanner;
use App\Extensions\Chatbot\System\Services\WorkcorePortalDataService;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ChatbotPortalActionController extends Controller
{
    public function __construct(
        protected WorkcorePortalDataService $dataService,
        protected ChatbotPortalActionPlanner $planner
    ) {
    }

    public function quickActions(Chatbot $chatbot, string $sessionId): JsonResponse
    {
        $customer = $this->customer($chatbot, $sessionId);

        return response()->json([
            'actions' => $this->dataService->quickActions($chatbot, $customer),
            'recent' => ChatbotPortalAction::query()
                ->where('chatbot_id', $chatbot->getKey())
                ->when($customer?->getKey(), fn ($query, $customerId) => $query->where('chatbot_customer_id', $customerId))
                ->latest('id')
                ->limit(12)
                ->get()
                ->map(fn (ChatbotPortalAction $action) => array_merge(
                    $action->toArray(),
                    ['plan' => $this->planner->present($action)]
                ))
                ->values(),
        ]);
    }

    public function store(Request $request, Chatbot $chatbot, string $sessionId): JsonResponse
    {
        $customer = $this->customer($chatbot, $sessionId);
        $conversation = $this->conversation($chatbot, $sessionId);

        $validated = $request->validate([
            'type' => ['required', 'string', 'max:80'],
            'label' => ['nullable', 'string', 'max:255'],
            'company_id' => ['nullable', 'integer'],
            'customer_id' => ['nullable', 'integer'],
            'site_id' => ['nullable', 'integer'],
            'quote_id' => ['nullable', 'integer'],
            'service_job_id' => ['nullable', 'integer'],
            'service_issue_id' => ['nullable', 'integer'],
            'checklist_id' => ['nullable', 'integer'],
            'invoice_id' => ['nullable', 'integer'],
            'notes' => ['nullable', 'string'],
            'payload' => ['nullable', 'array'],
        ]);

        $action = ChatbotPortalAction::query()->create([
            'chatbot_id' => $chatbot->getKey(),
            'chatbot_customer_id' => $customer?->getKey(),
            'conversation_id' => $conversation?->getKey(),
            'company_id' => $validated['company_id'] ?? null,
            'customer_id' => $validated['customer_id'] ?? $customer?->getKey(),
            'site_id' => $validated['site_id'] ?? null,
            'quote_id' => $validated['quote_id'] ?? null,
            'project_id' => $validated['service_job_id'] ?? null,
            'service_job_id' => $validated['service_job_id'] ?? null,
            'service_issue_id' => $validated['service_issue_id'] ?? null,
            'checklist_id' => $validated['checklist_id'] ?? null,
            'invoice_id' => $validated['invoice_id'] ?? null,
            'type' => $validated['type'],
            'label' => $validated['label'] ?? null,
            'notes' => $validated['notes'] ?? null,
            'payload' => array_merge($validated['payload'] ?? [], [
                'customer_id' => $validated['customer_id'] ?? $customer?->getKey(),
                'service_job_id' => $validated['service_job_id'] ?? null,
                'service_issue_id' => $validated['service_issue_id'] ?? null,
                'checklist_id' => $validated['checklist_id'] ?? null,
                'legacy_project_id' => $validated['service_job_id'] ?? null,
            ]),
            'status' => 'requested',
            'requested_at' => now(),
        ]);

        return response()->json([
            'message' => 'Portal action queued.',
            'action' => array_merge(
                $action->toArray(),
                ['plan' => $this->planner->present($action)]
            ),
        ], 201);
    }

    protected function customer(Chatbot $chatbot, string $sessionId): ?ChatbotCustomer
    {
        return ChatbotCustomer::query()
            ->where('chatbot_id', $chatbot->getKey())
            ->where(function ($query) use ($sessionId) {
                $query->where('payload->session_id', $sessionId)
                    ->orWhere('email', $sessionId);
            })
            ->latest('id')
            ->first();
    }

    protected function conversation(Chatbot $chatbot, string $sessionId): ?ChatbotConversation
    {
        return ChatbotConversation::query()
            ->where('chatbot_id', $chatbot->getKey())
            ->where('session_id', $sessionId)
            ->latest('id')
            ->first();
    }
}
