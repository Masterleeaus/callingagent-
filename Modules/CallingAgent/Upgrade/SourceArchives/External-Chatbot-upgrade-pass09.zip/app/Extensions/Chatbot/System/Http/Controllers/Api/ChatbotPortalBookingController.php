<?php

namespace App\Extensions\Chatbot\System\Http\Controllers\Api;

use App\Extensions\Chatbot\System\Models\Chatbot;
use App\Extensions\Chatbot\System\Models\ChatbotConversation;
use App\Extensions\Chatbot\System\Models\ChatbotCustomer;
use App\Extensions\Chatbot\System\Models\ChatbotPortalBookingRequest;
use App\Extensions\Chatbot\System\Services\WorkcorePortalDataService;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ChatbotPortalBookingController extends Controller
{
    public function __construct(protected WorkcorePortalDataService $dataService)
    {
    }

    public function index(Chatbot $chatbot, string $sessionId): JsonResponse
    {
        $customer = $this->customer($chatbot, $sessionId);

        return response()->json(array_merge($this->dataService->bookings($chatbot, $customer), [
            'quick_actions' => $this->dataService->quickActions($chatbot, $customer),
        ]));
    }

    public function store(Request $request, Chatbot $chatbot, string $sessionId): JsonResponse
    {
        $customer = $this->customer($chatbot, $sessionId);
        $conversation = ChatbotConversation::query()
            ->where('chatbot_id', $chatbot->getKey())
            ->where('session_id', $sessionId)
            ->latest('id')
            ->first();

        $validated = $request->validate([
            'company_id' => ['nullable', 'integer'],
            'site_id' => ['nullable', 'integer'],
            'quote_id' => ['nullable', 'integer'],
            'project_id' => ['nullable', 'integer'],
            'service_name' => ['required', 'string', 'max:255'],
            'frequency' => ['nullable', 'string', 'max:255'],
            'preferred_date' => ['nullable', 'date'],
            'preferred_window' => ['nullable', 'string', 'max:255'],
            'notes' => ['nullable', 'string'],
            'source' => ['nullable', 'string', 'max:100'],
            'extras' => ['nullable', 'array'],
            'request_payload' => ['nullable', 'array'],
        ]);

        $bookingRequest = ChatbotPortalBookingRequest::query()->create([
            'chatbot_id' => $chatbot->getKey(),
            'chatbot_customer_id' => $customer?->getKey(),
            'conversation_id' => $conversation?->getKey(),
            'company_id' => $validated['company_id'] ?? null,
            'site_id' => $validated['site_id'] ?? null,
            'quote_id' => $validated['quote_id'] ?? null,
            'project_id' => $validated['project_id'] ?? null,
            'service_name' => $validated['service_name'],
            'frequency' => $validated['frequency'] ?? null,
            'preferred_date' => $validated['preferred_date'] ?? null,
            'preferred_window' => $validated['preferred_window'] ?? null,
            'extras' => $validated['extras'] ?? null,
            'request_payload' => $validated['request_payload'] ?? null,
            'source' => $validated['source'] ?? 'portal',
            'notes' => $validated['notes'] ?? null,
            'status' => 'requested',
        ]);

        return response()->json([
            'message' => 'Booking request created.',
            'data' => $bookingRequest,
        ], 201);
    }

    protected function customer(Chatbot $chatbot, string $sessionId): ?ChatbotCustomer
    {
        return ChatbotCustomer::query()
            ->where('chatbot_id', $chatbot->getKey())
            ->where('session_id', $sessionId)
            ->first();
    }
}
