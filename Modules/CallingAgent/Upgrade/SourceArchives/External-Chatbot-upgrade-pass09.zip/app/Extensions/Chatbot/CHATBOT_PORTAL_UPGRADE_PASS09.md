# Chatbot Portal Upgrade Pass 09

Adds:

- document vault endpoint
- invoice payment redirect endpoint
- service-job visit timeline endpoint
- widget menu configuration service

Outcome:

Widget now supports contracts, receipts, photos, checklist evidence,
timeline playback, and invoice payment routing from inside chat UI.
