<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('ext_chatbot_portal_actions', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('chatbot_id');
            $table->unsignedBigInteger('chatbot_customer_id')->nullable();
            $table->unsignedBigInteger('conversation_id')->nullable();
            $table->unsignedBigInteger('company_id')->nullable();
            $table->unsignedBigInteger('site_id')->nullable();
            $table->unsignedBigInteger('quote_id')->nullable();
            $table->unsignedBigInteger('project_id')->nullable();
            $table->unsignedBigInteger('invoice_id')->nullable();
            $table->string('type', 80);
            $table->string('status', 40)->default('requested');
            $table->string('label')->nullable();
            $table->json('payload')->nullable();
            $table->text('notes')->nullable();
            $table->timestamp('requested_at')->nullable();
            $table->timestamp('processed_at')->nullable();
            $table->timestamps();

            $table->index(['chatbot_id', 'chatbot_customer_id'], 'ext_chatbot_portal_actions_chatbot_customer_idx');
            $table->index(['type', 'status'], 'ext_chatbot_portal_actions_type_status_idx');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ext_chatbot_portal_actions');
    }
};
