
Site Memory Layer

Stores:
- alarm codes
- pets
- parking
- access method
- priority rooms

Tables:
portal_site_access_notes
portal_site_preferences
portal_site_media
