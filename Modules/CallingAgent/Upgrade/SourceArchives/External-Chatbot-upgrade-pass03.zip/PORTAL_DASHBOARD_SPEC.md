
Portal Dashboard Spec

Sections:
- Upcoming Visits (projects filtered by status upcoming)
- Outstanding Invoices (invoices unpaid)
- Active Properties (sites)
- Notifications (portal_customer_notifications)

Integrations:
projects
sites
invoices
tickets
