<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('ext_chatbots')) {
            return;
        }

        Schema::table('ext_chatbots', function (Blueprint $table) {
            if (! Schema::hasColumn('ext_chatbots', 'portal_nav_items')) {
                $table->json('portal_nav_items')->nullable()->after('portal_settings');
            }

            if (! Schema::hasColumn('ext_chatbots', 'portal_help_center_title')) {
                $table->string('portal_help_center_title')->nullable()->after('portal_nav_items');
            }

            if (! Schema::hasColumn('ext_chatbots', 'portal_document_title')) {
                $table->string('portal_document_title')->nullable()->after('portal_help_center_title');
            }
        });
    }

    public function down(): void
    {
        if (! Schema::hasTable('ext_chatbots')) {
            return;
        }

        Schema::table('ext_chatbots', function (Blueprint $table) {
            foreach (['portal_nav_items', 'portal_help_center_title', 'portal_document_title'] as $column) {
                if (Schema::hasColumn('ext_chatbots', $column)) {
                    $table->dropColumn($column);
                }
            }
        });
    }
};
