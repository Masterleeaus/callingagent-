<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('ext_chatbot_portal_booking_requests')) {
            return;
        }

        Schema::create('ext_chatbot_portal_booking_requests', function (Blueprint $table) {
            $table->id();
            $table->foreignId('chatbot_id')->constrained('ext_chatbots')->cascadeOnDelete();
            $table->unsignedBigInteger('chatbot_customer_id')->nullable();
            $table->unsignedBigInteger('conversation_id')->nullable();
            $table->unsignedBigInteger('company_id')->nullable();
            $table->unsignedBigInteger('site_id')->nullable()->index();
            $table->unsignedBigInteger('quote_id')->nullable();
            $table->unsignedBigInteger('project_id')->nullable();
            $table->string('service_name');
            $table->string('frequency')->nullable();
            $table->date('preferred_date')->nullable();
            $table->string('preferred_window')->nullable();
            $table->json('extras')->nullable();
            $table->json('request_payload')->nullable();
            $table->string('source')->default('portal');
            $table->string('status')->default('requested');
            $table->text('notes')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ext_chatbot_portal_booking_requests');
    }
};
