<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('ext_chatbot_portal_document_links')) {
            return;
        }

        Schema::create('ext_chatbot_portal_document_links', function (Blueprint $table) {
            $table->id();
            $table->foreignId('chatbot_id')->constrained('ext_chatbots')->cascadeOnDelete();
            $table->unsignedBigInteger('chatbot_customer_id')->nullable();
            $table->unsignedBigInteger('company_id')->nullable();
            $table->unsignedBigInteger('site_id')->nullable();
            $table->unsignedBigInteger('workcore_invoice_id')->nullable();
            $table->unsignedBigInteger('workcore_contract_id')->nullable();
            $table->unsignedBigInteger('workcore_quote_id')->nullable();
            $table->string('type')->default('document');
            $table->string('title');
            $table->string('file_name')->nullable();
            $table->text('file_url')->nullable();
            $table->json('payload')->nullable();
            $table->timestamp('published_at')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ext_chatbot_portal_document_links');
    }
};
