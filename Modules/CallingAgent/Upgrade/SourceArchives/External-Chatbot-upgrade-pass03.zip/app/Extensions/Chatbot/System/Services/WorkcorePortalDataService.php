<?php

namespace App\Extensions\Chatbot\System\Services;

use App\Extensions\Chatbot\System\Models\Chatbot;
use App\Extensions\Chatbot\System\Models\ChatbotCustomer;
use App\Extensions\Chatbot\System\Models\ChatbotPortalBookingRequest;
use App\Extensions\Chatbot\System\Models\ChatbotPortalDocumentLink;
use App\Helpers\Classes\MarketplaceHelper;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

class WorkcorePortalDataService
{
    public function bookings(Chatbot $chatbot, ?ChatbotCustomer $customer, int $limit = 20): array
    {
        return [
            'requests' => ChatbotPortalBookingRequest::query()
                ->where('chatbot_id', $chatbot->getKey())
                ->when($customer?->getKey(), fn ($query, $customerId) => $query->where('chatbot_customer_id', $customerId))
                ->latest()
                ->limit($limit)
                ->get(),
            'quotes' => $this->workcoreQuotes($customer, $limit),
            'projects' => $this->workcoreProjects($customer, $limit),
        ];
    }

    public function visits(?ChatbotCustomer $customer, int $limit = 20): array
    {
        return [
            'projects' => $this->workcoreProjects($customer, $limit),
            'time_logs' => $this->workcoreTimeLogs($customer, $limit),
        ];
    }

    public function invoices(Chatbot $chatbot, ?ChatbotCustomer $customer, int $limit = 20): array
    {
        return [
            'invoices' => $this->workcoreInvoices($customer, $limit),
            'documents' => ChatbotPortalDocumentLink::query()
                ->where('chatbot_id', $chatbot->getKey())
                ->when($customer?->getKey(), fn ($query, $customerId) => $query->where('chatbot_customer_id', $customerId))
                ->whereIn('type', ['invoice', 'receipt', 'contract', 'quote'])
                ->latest('published_at')
                ->limit($limit)
                ->get(),
        ];
    }

    protected function workcoreQuotes(?ChatbotCustomer $customer, int $limit): Collection
    {
        if (! MarketplaceHelper::isRegistered('workcore') || ! DB::getSchemaBuilder()->hasTable('quotes')) {
            return collect();
        }

        return DB::table('quotes')
            ->when($customer?->getKey(), function ($query) use ($customer) {
                $query->where(function ($subQuery) use ($customer) {
                    foreach (['client_id', 'customer_id', 'user_id'] as $column) {
                        if (DB::getSchemaBuilder()->hasColumn('quotes', $column)) {
                            $subQuery->orWhere($column, $customer->getKey());
                        }
                    }
                });
            })
            ->orderByDesc('id')
            ->limit($limit)
            ->get();
    }

    protected function workcoreProjects(?ChatbotCustomer $customer, int $limit): Collection
    {
        if (! MarketplaceHelper::isRegistered('workcore') || ! DB::getSchemaBuilder()->hasTable('projects')) {
            return collect();
        }

        $query = DB::table('projects');

        if ($customer?->getKey()) {
            $query->where(function ($subQuery) use ($customer) {
                foreach (['client_id', 'customer_id', 'user_id'] as $column) {
                    if (DB::getSchemaBuilder()->hasColumn('projects', $column)) {
                        $subQuery->orWhere($column, $customer->getKey());
                    }
                }
            });
        }

        return $query->orderByDesc('id')->limit($limit)->get();
    }

    protected function workcoreTimeLogs(?ChatbotCustomer $customer, int $limit): Collection
    {
        if (! MarketplaceHelper::isRegistered('workcore') || ! DB::getSchemaBuilder()->hasTable('project_time_logs')) {
            return collect();
        }

        $query = DB::table('project_time_logs');

        if ($customer?->getKey() && DB::getSchemaBuilder()->hasTable('projects')) {
            $query->join('projects', 'projects.id', '=', 'project_time_logs.project_id')
                ->where(function ($subQuery) use ($customer) {
                    foreach (['projects.client_id', 'projects.customer_id', 'projects.user_id'] as $column) {
                        $subQuery->orWhere($column, $customer->getKey());
                    }
                })
                ->select('project_time_logs.*');
        }

        return $query->orderByDesc('project_time_logs.id')->limit($limit)->get();
    }

    protected function workcoreInvoices(?ChatbotCustomer $customer, int $limit): Collection
    {
        if (! MarketplaceHelper::isRegistered('workcore') || ! DB::getSchemaBuilder()->hasTable('invoices')) {
            return collect();
        }

        $query = DB::table('invoices');

        if ($customer?->getKey()) {
            $query->where(function ($subQuery) use ($customer) {
                foreach (['client_id', 'customer_id', 'user_id'] as $column) {
                    if (DB::getSchemaBuilder()->hasColumn('invoices', $column)) {
                        $subQuery->orWhere($column, $customer->getKey());
                    }
                }
            });
        }

        return $query->orderByDesc('id')->limit($limit)->get();
    }
}
