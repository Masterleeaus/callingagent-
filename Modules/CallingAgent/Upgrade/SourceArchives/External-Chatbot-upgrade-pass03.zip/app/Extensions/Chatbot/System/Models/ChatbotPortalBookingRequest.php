<?php

namespace App\Extensions\Chatbot\System\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ChatbotPortalBookingRequest extends Model
{
    protected $table = 'ext_chatbot_portal_booking_requests';

    protected $fillable = [
        'chatbot_id',
        'chatbot_customer_id',
        'conversation_id',
        'company_id',
        'site_id',
        'quote_id',
        'project_id',
        'service_name',
        'frequency',
        'preferred_date',
        'preferred_window',
        'extras',
        'request_payload',
        'source',
        'status',
        'notes',
    ];

    protected $casts = [
        'preferred_date' => 'date',
        'extras' => 'array',
        'request_payload' => 'array',
    ];

    public function chatbot(): BelongsTo
    {
        return $this->belongsTo(Chatbot::class, 'chatbot_id');
    }

    public function customer(): BelongsTo
    {
        return $this->belongsTo(ChatbotCustomer::class, 'chatbot_customer_id');
    }

    public function conversation(): BelongsTo
    {
        return $this->belongsTo(ChatbotConversation::class, 'conversation_id');
    }
}
