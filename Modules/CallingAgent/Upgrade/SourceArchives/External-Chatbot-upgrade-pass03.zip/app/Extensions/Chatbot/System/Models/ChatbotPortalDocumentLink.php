<?php

namespace App\Extensions\Chatbot\System\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ChatbotPortalDocumentLink extends Model
{
    protected $table = 'ext_chatbot_portal_document_links';

    protected $fillable = [
        'chatbot_id',
        'chatbot_customer_id',
        'company_id',
        'site_id',
        'workcore_invoice_id',
        'workcore_contract_id',
        'workcore_quote_id',
        'type',
        'title',
        'file_name',
        'file_url',
        'payload',
        'published_at',
    ];

    protected $casts = [
        'payload' => 'array',
        'published_at' => 'datetime',
    ];

    public function chatbot(): BelongsTo
    {
        return $this->belongsTo(Chatbot::class, 'chatbot_id');
    }

    public function customer(): BelongsTo
    {
        return $this->belongsTo(ChatbotCustomer::class, 'chatbot_customer_id');
    }
}
