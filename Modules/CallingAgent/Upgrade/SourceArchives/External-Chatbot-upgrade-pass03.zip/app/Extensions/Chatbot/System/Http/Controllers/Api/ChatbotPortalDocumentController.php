<?php

namespace App\Extensions\Chatbot\System\Http\Controllers\Api;

use App\Extensions\Chatbot\System\Models\Chatbot;
use App\Extensions\Chatbot\System\Models\ChatbotCustomer;
use App\Extensions\Chatbot\System\Models\ChatbotPortalDocumentLink;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ChatbotPortalDocumentController extends Controller
{
    public function index(Chatbot $chatbot, string $sessionId): JsonResponse
    {
        $customer = ChatbotCustomer::query()
            ->where('chatbot_id', $chatbot->getKey())
            ->where('session_id', $sessionId)
            ->first();

        $documents = ChatbotPortalDocumentLink::query()
            ->where('chatbot_id', $chatbot->getKey())
            ->when($customer?->getKey(), fn ($query, $customerId) => $query->where('chatbot_customer_id', $customerId))
            ->latest('published_at')
            ->paginate(20);

        return response()->json($documents);
    }

    public function store(Request $request, Chatbot $chatbot, string $sessionId): JsonResponse
    {
        $customer = ChatbotCustomer::query()
            ->where('chatbot_id', $chatbot->getKey())
            ->where('session_id', $sessionId)
            ->first();

        $validated = $request->validate([
            'company_id' => ['nullable', 'integer'],
            'site_id' => ['nullable', 'integer'],
            'workcore_invoice_id' => ['nullable', 'integer'],
            'workcore_contract_id' => ['nullable', 'integer'],
            'workcore_quote_id' => ['nullable', 'integer'],
            'type' => ['required', 'string', 'max:100'],
            'title' => ['required', 'string', 'max:255'],
            'file_name' => ['nullable', 'string', 'max:255'],
            'file_url' => ['nullable', 'string', 'max:2048'],
            'payload' => ['nullable', 'array'],
            'published_at' => ['nullable', 'date'],
        ]);

        $document = ChatbotPortalDocumentLink::query()->create([
            'chatbot_id' => $chatbot->getKey(),
            'chatbot_customer_id' => $customer?->getKey(),
            'company_id' => $validated['company_id'] ?? null,
            'site_id' => $validated['site_id'] ?? null,
            'workcore_invoice_id' => $validated['workcore_invoice_id'] ?? null,
            'workcore_contract_id' => $validated['workcore_contract_id'] ?? null,
            'workcore_quote_id' => $validated['workcore_quote_id'] ?? null,
            'type' => $validated['type'],
            'title' => $validated['title'],
            'file_name' => $validated['file_name'] ?? null,
            'file_url' => $validated['file_url'] ?? null,
            'payload' => $validated['payload'] ?? null,
            'published_at' => $validated['published_at'] ?? now(),
        ]);

        return response()->json([
            'message' => 'Portal document linked.',
            'data' => $document,
        ], 201);
    }
}
