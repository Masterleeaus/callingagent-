# Chatbot Portal Upgrade Pass 02

This pass extends the external chatbot into a stronger customer portal bridge for WorkCore-powered cleaning flows.

## Added
- Portal booking request storage
- Portal document vault links
- Booking, visit, invoice, and document API endpoints
- Notification read endpoint
- Site profile save endpoint
- Recurring service save endpoint
- Feedback creation endpoint
- WorkCore data aggregation service for quotes, projects, time logs, and invoices
- Additional portal nav config fields on `ext_chatbots`

## Route surfaces
- `GET /api/v2/chatbot/{chatbot}/session/{sessionId}/portal/bookings`
- `POST /api/v2/chatbot/{chatbot}/session/{sessionId}/portal/bookings`
- `GET /api/v2/chatbot/{chatbot}/session/{sessionId}/portal/visits`
- `GET /api/v2/chatbot/{chatbot}/session/{sessionId}/portal/invoices`
- `GET /api/v2/chatbot/{chatbot}/session/{sessionId}/portal/documents`
- `POST /api/v2/chatbot/{chatbot}/session/{sessionId}/portal/documents`
- `POST /api/v2/chatbot/{chatbot}/session/{sessionId}/portal/notifications/{notification}/read`
- `POST /api/v2/chatbot/{chatbot}/session/{sessionId}/portal/site-profiles`
- `POST /api/v2/chatbot/{chatbot}/session/{sessionId}/portal/recurring-services`
- `POST /api/v2/chatbot/{chatbot}/session/{sessionId}/portal/feedback`

## Intent
Reuse WorkCore tables for invoices, quotes, projects, and time logs while keeping only a small portal-side bridge schema in the chatbot extension.
