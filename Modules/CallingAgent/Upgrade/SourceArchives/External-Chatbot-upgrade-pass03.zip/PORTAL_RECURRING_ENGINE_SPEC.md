
Recurring Service Engine

Controls:
- pause_service
- skip_visit
- change_frequency
- permanent_extras

Tables:
portal_recurring_services
portal_recurring_service_rules
portal_booking_skips
